---
layout: track
title: "Headphones In S01"
permalink: /tracks/headphones-in-s01/
description: ""
image: "/assets/covers/headphones-in-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:42"
album: "Stranger Vibes"
mood: ["Hopeful"]
genre: ["lo-fi", "ambient", "chillwave"]
bpm: 118
key: "D"
---

Explore more vibes in the [StudioRich track library](/tracks/).
