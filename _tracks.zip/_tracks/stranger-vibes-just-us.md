---
layout: track
title: Stranger Vibes Just Us
permalink: /tracks/stranger-vibes-just-us/
description: ''
image: /assets/covers/stranger-vibes-just-us.webp
image_ready: false
date: 2025-01-01
duration: '2:48'
album: Stranger Vibes
mood:
- Playful
genre:
- lo-fi
bpm: 93
key: G
image_jpg: /assets/covers/stranger-vibes-just-us.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
