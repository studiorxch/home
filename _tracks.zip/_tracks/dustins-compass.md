---
layout: track
title: Dustins Compass
permalink: /tracks/dustins-compass/
description: ''
image: /assets/covers/dustins-compass.webp
image_ready: false
date: 2025-01-01
duration: '2:23'
album: Stranger Vibes
mood:
- Hopeful
genre:
- lo-fi
- chillhop
- ambient
bpm: 120
key: F#
image_jpg: /assets/covers/dustins-compass.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
