---
layout: track
title: Submerged Notes
permalink: /tracks/submerged-notes/
description: ''
image: /assets/covers/submerged-notes.webp
image_ready: false
date: 2025-01-01
duration: '2:09'
album: Stranger Vibes
mood: []
genre:
- lo-fi
bpm: 120
key: C
image_jpg: /assets/covers/submerged-notes.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
