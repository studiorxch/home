---
layout: track
title: Walkie Crackle S01
permalink: /tracks/walkie-crackle-s01/
description: ''
image: /assets/covers/walkie-crackle-s01.webp
image_ready: false
date: 2025-01-01
duration: '1:44'
album: Stranger Vibes
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- swing
- cinematic
bpm: 83
key: F
image_jpg: /assets/covers/walkie-crackle-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
