---
layout: track
title: "Light from a Distance S1"
permalink: /tracks/light-from-a-distance-s1/
description: ""
image: "/assets/covers/light-from-a-distance-s1.webp"
image_ready: false
date: 2025-01-01
duration: "3:00"
album: "Run Loop"
mood: ["Dreamy", "Nostalgic"]
genre: ["ambient", "minimal"]
bpm: 88
key: "E"
---

Explore more vibes in the [StudioRich track library](/tracks/).
