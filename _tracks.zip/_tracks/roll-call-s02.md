---
layout: track
title: Roll Call S02
permalink: /tracks/roll-call-s02/
description: ''
image: /assets/covers/roll-call-s02.webp
image_ready: false
date: 2025-01-01
duration: '2:02'
album: Stranger Vibes
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi hip hop
- jazz rap
bpm: 82
key: G
image_jpg: /assets/covers/roll-call-s02.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
