---
layout: track
title: "Soul Trace"
permalink: /tracks/soul-trace/
description: ""
image: "/assets/covers/soul-trace.webp"
image_ready: false
date: 2025-01-01
duration: "2:51"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "soul"]
bpm: 85
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
