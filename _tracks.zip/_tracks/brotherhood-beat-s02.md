---
layout: track
title: Brotherhood Beat S02
permalink: /tracks/brotherhood-beat-s02/
description: ''
image: /assets/covers/brotherhood-beat-s02.webp
image_ready: false
date: 2025-01-01
duration: '1:39'
album: Stranger Vibes
mood:
- Chill
genre:
- lo-fi
- indie
- chill
bpm: 86
key: C#
image_jpg: /assets/covers/brotherhood-beat-s02.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
