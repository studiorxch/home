---
layout: track
title: "Nowhere Shortcut"
permalink: /tracks/nowhere-shortcut/
description: ""
image: "/assets/covers/nowhere-shortcut.webp"
image_ready: false
date: 2025-01-01
duration: "1:54"
album: "Stranger Vibes"
mood: ["Hopeful", "Playful"]
genre: ["lo-fi", "experimental"]
bpm: 101
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
