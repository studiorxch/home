---
layout: track
title: "Vaporphase"
permalink: /tracks/vaporphase/
description: ""
image: "/assets/covers/vaporphase.webp"
image_ready: false
date: 2025-01-01
duration: "2:00"
album: "The Way the Air Moves"
mood: ["Melancholy", "Dreamy", "Nostalgic"]
genre: ["ambient", "lo-fi", "jungle"]
bpm: 80
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
