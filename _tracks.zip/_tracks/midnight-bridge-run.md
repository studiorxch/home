---
layout: track
title: Midnight Bridge Run
permalink: /tracks/midnight-bridge-run/
description: ''
image: /assets/covers/midnight-bridge-run.webp
image_ready: false
date: 2025-01-01
duration: '4:09'
album: Run Loop
mood:
- Chill
genre:
- jungle
- drum and bass
- atmospheric
bpm: 77
key: B
image_jpg: /assets/covers/midnight-bridge-run.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
