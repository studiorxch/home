---
layout: track
title: Touch Echo
permalink: /tracks/touch-echo/
description: ''
image: /assets/covers/touch-echo.webp
image_ready: false
date: 2025-01-01
duration: '4:25'
album: The Way the Air Moves
mood:
- Dreamy
- Nostalgic
genre:
- cinematic
- lo-fi
- jungle
bpm: 87
key: C#
image_jpg: /assets/covers/touch-echo.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
