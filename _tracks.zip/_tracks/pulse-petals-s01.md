---
layout: track
title: "Pulse Petals S01"
permalink: /tracks/pulse-petals-s01/
description: ""
image: "/assets/covers/pulse-petals-s01.webp"
image_ready: false
date: 2025-01-01
duration: "1:47"
album: "Emotional Lift"
mood: ["Playful"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 90
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
