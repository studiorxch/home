---
layout: track
title: "Signal Collision"
permalink: /tracks/signal-collision/
description: ""
image: "/assets/covers/signal-collision.webp"
image_ready: false
date: 2025-01-01
duration: "4:29"
album: "Run Loop"
mood: ["Aggressive"]
genre: ["electronic", "experimental", "post-rock"]
bpm: 150
key: "A"
---

Explore more vibes in the [StudioRich track library](/tracks/).
