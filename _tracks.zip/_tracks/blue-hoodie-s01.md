---
layout: track
title: Blue Hoodie S01
permalink: /tracks/blue-hoodie-s01/
description: ''
image: /assets/covers/blue-hoodie-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:28'
album: Stranger Vibes
mood:
- Melancholy
genre:
- lo-fi
- chillwave
- ambient
bpm: 72
key: F
image_jpg: /assets/covers/blue-hoodie-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
