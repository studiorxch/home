---
layout: track
title: "Blue Hoodie"
permalink: /tracks/blue-hoodie/
description: ""
image: "/assets/covers/blue-hoodie.webp"
image_ready: true
date: 2025-01-01
duration: "2:28"
album: "Stranger Vibes"
mood: ["Melancholy"]
genre: ["lo-fi", "chillwave", "ambient"]
bpm: 72
key: "F"
---

Explore more vibes in the [StudioRich track library](/tracks/).
