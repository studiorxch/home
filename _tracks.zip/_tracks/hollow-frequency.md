---
layout: track
title: Hollow Frequency
permalink: /tracks/hollow-frequency/
description: ''
image: /assets/covers/hollow-frequency.webp
image_ready: false
date: 2025-01-01
duration: '2:40'
album: The Way the Air Moves
mood: []
genre:
- lo-fi
- jungle
- ambient
bpm: 120
key: D
image_jpg: /assets/covers/hollow-frequency.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
