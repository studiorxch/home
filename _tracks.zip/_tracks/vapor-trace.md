---
layout: track
title: "Vapor Trace"
permalink: /tracks/vapor-trace/
description: ""
image: "/assets/covers/vapor-trace.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Eunoia"
mood: ["Tense"]
genre: ["ambient", "electronic", "experimental"]
bpm: 125
key: "B"
---

Explore more vibes in the [StudioRich track library](/tracks/).
