---
layout: track
title: Static Sleepwalker
permalink: /tracks/static-sleepwalker/
description: ''
image: /assets/covers/static-sleepwalker.webp
image_ready: false
date: 2025-01-01
duration: '1:58'
album: Stranger Vibes
mood:
- Energetic
- Aggressive
genre:
- lo-fi
- ambient
- downtempo
bpm: 162
key: C
image_jpg: /assets/covers/static-sleepwalker.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
