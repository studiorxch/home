---
layout: track
title: Static Door Echo
permalink: /tracks/static-door-echo/
description: ''
image: /assets/covers/static-door-echo.webp
image_ready: false
date: 2025-01-01
duration: '3:40'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
- ambient
- electronic
bpm: 144
key: Eb
image_jpg: /assets/covers/static-door-echo.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
