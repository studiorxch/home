---
layout: track
title: "Sodium Flicker"
permalink: /tracks/sodium-flicker/
description: ""
image: "/assets/covers/sodium-flicker.webp"
image_ready: false
date: 2025-01-01
duration: "3:40"
album: "Run Loop"
mood: ["Dreamy"]
genre: ["electronic", "ambient", "indie rock"]
bpm: 105
key: "D"
---

Explore more vibes in the [StudioRich track library](/tracks/).
