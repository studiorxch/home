---
layout: track
title: Petal Fade
permalink: /tracks/petal-fade/
description: ''
image: /assets/covers/petal-fade.webp
image_ready: false
date: 2025-01-01
duration: '3:47'
album: The Way the Air Moves
mood:
- Chill
genre:
- cinematic
- lo-fi
- jungle
bpm: 85
key: F
image_jpg: /assets/covers/petal-fade.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
