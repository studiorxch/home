---
layout: track
title: Sodium Flicker S1
permalink: /tracks/sodium-flicker-s1/
description: ''
image: /assets/covers/sodium-flicker-s1.webp
image_ready: false
date: 2025-01-01
duration: '2:43'
album: Run Loop
mood:
- Dreamy
- Nostalgic
genre:
- electronic
- ambient
- indie rock
bpm: 90
key: F#
image_jpg: /assets/covers/sodium-flicker-s1.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
