---
layout: track
title: Lucas Loop S02
permalink: /tracks/lucas-loop-s02/
description: ''
image: /assets/covers/lucas-loop-s02.webp
image_ready: false
date: 2025-01-01
duration: '2:24'
album: Stranger Vibes
mood:
- Melancholy
genre:
- lo-fi
- chillhop
- ambient
bpm: 79
key: C
image_jpg: /assets/covers/lucas-loop-s02.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
