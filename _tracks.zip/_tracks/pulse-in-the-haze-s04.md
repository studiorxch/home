---
layout: track
title: "Pulse In The Haze S04"
permalink: /tracks/pulse-in-the-haze-s04/
description: ""
image: "/assets/covers/pulse-in-the-haze-s04.webp"
image_ready: false
date: 2025-01-01
duration: "2:17"
album: "The Way the Air Moves"
mood: ["Melancholy", "Dreamy", "Nostalgic"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 85
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
