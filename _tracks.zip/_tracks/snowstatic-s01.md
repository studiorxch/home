---
layout: track
title: "Snowstatic S01"
permalink: /tracks/snowstatic-s01/
description: ""
image: "/assets/covers/snowstatic-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:41"
album: "The Way the Air Moves"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 172
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
