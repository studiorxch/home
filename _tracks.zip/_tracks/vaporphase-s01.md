---
layout: track
title: "Vaporphase S01"
permalink: /tracks/vaporphase-s01/
description: ""
image: "/assets/covers/vaporphase-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:27"
album: "The Way the Air Moves"
mood: ["Energetic", "Aggressive"]
genre: ["ambient", "lo-fi", "jungle"]
bpm: 166
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
