---
layout: track
title: "Celestial Drift"
permalink: /tracks/celestial-drift/
description: ""
image: "/assets/covers/celestial-drift.webp"
image_ready: false
date: 2025-01-01
duration: "3:11"
album: "Eunoia"
mood: ["Chill"]
genre: ["ambient", "electronic", "experimental"]
bpm: 80
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
