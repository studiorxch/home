---
layout: track
title: "Muted Sunrise"
permalink: /tracks/muted-sunrise/
description: ""
image: "/assets/covers/muted-sunrise.webp"
image_ready: false
date: 2025-01-01
duration: "2:39"
album: "Stranger Vibes"
mood: ["Hopeful"]
genre: ["lo-fi", "ambient"]
bpm: 120
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
