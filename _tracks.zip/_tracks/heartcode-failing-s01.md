---
layout: track
title: Heartcode Failing S01
permalink: /tracks/heartcode-failing-s01/
description: ''
image: /assets/covers/heartcode-failing-s01.webp
image_ready: false
date: 2025-01-01
duration: '1:29'
album: Run Loop
mood:
- Aggressive
genre:
- electronic
- experimental pop
bpm: 152
key: F
image_jpg: /assets/covers/heartcode-failing-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
