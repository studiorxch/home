---
layout: track
title: Cloudtype II
permalink: /tracks/cloudtype-ii/
description: ''
image: /assets/covers/cloudtype-ii.webp
image_ready: false
date: 2025-01-01
duration: '2:03'
album: The Way the Air Moves
mood:
- Aggressive
genre:
- ambient
- lo-fi
- chillout
bpm: 140
key: B
image_jpg: /assets/covers/cloudtype-ii.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
