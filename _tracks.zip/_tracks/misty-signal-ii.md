---
layout: track
title: "Misty Signal II"
permalink: /tracks/misty-signal-ii/
description: ""
image: "/assets/covers/misty-signal-ii.webp"
image_ready: false
date: 2025-01-01
duration: "3:59"
album: "The Way the Air Moves"
mood: []
genre: ["ambient", "lo-fi", "downtempo"]
bpm: 130
key: "A"
---

Explore more vibes in the [StudioRich track library](/tracks/).
