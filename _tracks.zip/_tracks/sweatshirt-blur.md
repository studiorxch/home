---
layout: track
title: "Sweatshirt Blur"
permalink: /tracks/sweatshirt-blur/
description: ""
image: "/assets/covers/sweatshirt-blur.webp"
image_ready: false
date: 2025-01-01
duration: "2:53"
album: "Run Loop"
mood: ["Chill"]
genre: ["r&b", "trap"]
bpm: 89
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
