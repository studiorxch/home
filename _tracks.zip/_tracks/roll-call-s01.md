---
layout: track
title: "Roll Call S01"
permalink: /tracks/roll-call-s01/
description: ""
image: "/assets/covers/roll-call-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:07"
album: "Stranger Vibes"
mood: ["Dreamy", "Nostalgic"]
genre: ["lo-fi hip hop", "jazz rap"]
bpm: 85
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
