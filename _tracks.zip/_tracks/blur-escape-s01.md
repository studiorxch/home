---
layout: track
title: Blur Escape S01
permalink: /tracks/blur-escape-s01/
description: ''
image: /assets/covers/blur-escape-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:20'
album: Stranger Vibes
mood: []
genre:
- lo-fi
- experimental
- ambient
bpm: 120
key: Eb
image_jpg: /assets/covers/blur-escape-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
