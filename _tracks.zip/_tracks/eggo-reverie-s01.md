---
layout: track
title: "Eggo Reverie S01"
permalink: /tracks/eggo-reverie-s01/
description: ""
image: "/assets/covers/eggo-reverie-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:17"
album: "Stranger Vibes"
mood: ["Tense"]
genre: ["lo-fi", "ambient", "cinematic"]
bpm: 120
key: "E"
---

Explore more vibes in the [StudioRich track library](/tracks/).
