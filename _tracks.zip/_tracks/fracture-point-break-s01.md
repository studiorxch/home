---
layout: track
title: "Fracture Point Break S01"
permalink: /tracks/fracture-point-break-s01/
description: ""
image: "/assets/covers/fracture-point-break-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:09"
album: "Stranger Vibes"
mood: ["Aggressive"]
genre: ["lo-fi", "glitch-fusion", "experimental"]
bpm: 152
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
