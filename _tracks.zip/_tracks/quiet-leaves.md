---
layout: track
title: "Quiet Leaves"
permalink: /tracks/quiet-leaves/
description: ""
image: "/assets/covers/quiet-leaves.webp"
image_ready: false
date: 2025-01-01
duration: "3:00"
album: "Stranger Vibes"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi", "electronic", "cinematic"]
bpm: 185
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
