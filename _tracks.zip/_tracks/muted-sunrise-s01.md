---
layout: track
title: "Muted Sunrise S01"
permalink: /tracks/muted-sunrise-s01/
description: ""
image: "/assets/covers/muted-sunrise-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:39"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "ambient"]
bpm: 120
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
