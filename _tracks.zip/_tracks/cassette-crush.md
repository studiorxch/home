---
layout: track
title: Cassette Crush
permalink: /tracks/cassette-crush/
description: 'Cassette Crush (Remix) breathes new life into lo-fi nostalgia. Dreamy guitars mingle with vintage synths and mellow drums, all wrapped in a soft crackle. The remix brings a slightly brighter lift while keeping that faded memory feel intact.'
image: /assets/covers/cassette-crush.webp
image_ready: false
date: 2025-01-01
duration: '1:57'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
bpm: 144
key: C
image_jpg: /assets/covers/cassette-crush.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
