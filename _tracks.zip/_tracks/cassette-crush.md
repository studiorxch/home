---
layout: track
title: Cassette Crush
permalink: /tracks/cassette-crush/
description: ''
image: /assets/covers/cassette-crush.webp
image_ready: false
date: 2025-01-01
duration: '1:57'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
bpm: 144
key: C
image_jpg: /assets/covers/cassette-crush.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
