---
layout: track
title: "Memory Drip"
permalink: /tracks/memory-drip/
description: ""
image: "/assets/covers/memory-drip.webp"
image_ready: false
date: 2025-01-01
duration: "3:47"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "electronic"]
bpm: 84
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
