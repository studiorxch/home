---
layout: track
title: Echo Apartments
permalink: /tracks/echo-apartments/
description: ''
image: /assets/covers/echo-apartments.webp
image_ready: false
date: 2025-01-01
duration: '1:56'
album: Run Loop
mood:
- Hopeful
genre:
- jazz
- ambient
bpm: 118
key: F
image_jpg: /assets/covers/echo-apartments.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
