---
layout: track
title: "Dream Sprint"
permalink: /tracks/dream-sprint/
description: ""
image: "/assets/covers/dream-sprint.webp"
image_ready: false
date: 2025-01-01
duration: "4:26"
album: "Run Loop"
mood: ["Dreamy", "Nostalgic"]
genre: ["electronic", "jungle", "synthpop"]
bpm: 87
key: "F"
---

Explore more vibes in the [StudioRich track library](/tracks/).
