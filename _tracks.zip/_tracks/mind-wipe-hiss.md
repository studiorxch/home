---
layout: track
title: Mind Wipe Hiss
permalink: /tracks/mind-wipe-hiss/
description: ''
image: /assets/covers/mind-wipe-hiss.webp
image_ready: false
date: 2025-01-01
duration: '3:11'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
- cinematic
- electronic
bpm: 151
key: Bb
image_jpg: /assets/covers/mind-wipe-hiss.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
