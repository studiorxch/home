---
layout: track
title: Starlight Murmur
permalink: /tracks/starlight-murmur/
description: ''
image: /assets/covers/starlight-murmur.webp
image_ready: false
date: 2025-01-01
duration: '4:00'
album: Eunoia
mood:
- Tense
genre:
- ambient
- electronic
- experimental
bpm: 140
key: F
image_jpg: /assets/covers/starlight-murmur.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
