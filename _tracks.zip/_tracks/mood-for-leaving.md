---
layout: track
title: Mood For Leaving
permalink: /tracks/mood-for-leaving/
description: ''
image: /assets/covers/mood-for-leaving.webp
image_ready: false
date: 2025-01-01
duration: '1:28'
album: Stranger Vibes
mood:
- Playful
genre:
- lo-fi
bpm: 95
key: Ab
image_jpg: /assets/covers/mood-for-leaving.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
