---
layout: track
title: "Maxine's Drift S01"
permalink: /tracks/maxines-drift-s01/
description: ""
image: "/assets/covers/maxines-drift-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:11"
album: "Stranger Vibes"
mood: ["Hopeful"]
genre: ["lo-fi", "indie", "introspective"]
bpm: 120
key: "F"
---

Explore more vibes in the [StudioRich track library](/tracks/).
