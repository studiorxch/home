---
layout: track
title: "Fourth Period Fog S01"
permalink: /tracks/fourth-period-fog-s01/
description: ""
image: "/assets/covers/fourth-period-fog-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:23"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "indie", "dream pop"]
bpm: 124
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
