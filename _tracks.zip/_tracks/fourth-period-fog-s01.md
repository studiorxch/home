---
layout: track
title: Fourth Period Fog S01
permalink: /tracks/fourth-period-fog-s01/
description: "Fourth Period Fog S01 is a lo-fi, indie, dreamy track \u2014 89 BPM\
  \ in B\u266D. Mood: sleepy nostalgia. Feels like a warm bus ride through foggy memory."
image: /assets/covers/fourth-period-fog-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:23'
album: Stranger Vibes
mood: []
genre:
- lo-fi
- indie
- dream pop
bpm: 124
key: C#
image_jpg: /assets/covers/fourth-period-fog-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
