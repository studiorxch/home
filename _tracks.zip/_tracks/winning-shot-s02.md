---
layout: track
title: "Winning Shot S02"
permalink: /tracks/winning-shot-s02/
description: ""
image: "/assets/covers/winning-shot-s02.webp"
image_ready: false
date: 2025-01-01
duration: "2:33"
album: "Stranger Vibes"
mood: ["Playful"]
genre: ["lo-fi", "hip-hop", "electronic"]
bpm: 94
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
