---
layout: track
title: Ghosted Messages S1
permalink: /tracks/ghosted-messages-s1/
description: ''
image: /assets/covers/ghosted-messages-s1.webp
image_ready: false
date: 2025-01-01
duration: '1:54'
album: Run Loop
mood:
- Playful
genre:
- trap
- r&b
bpm: 93
key: F#
image_jpg: /assets/covers/ghosted-messages-s1.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
