---
layout: track
title: Mute Reflex
permalink: /tracks/mute-reflex/
description: ''
image: /assets/covers/mute-reflex.webp
image_ready: false
date: 2025-01-01
duration: '4:50'
album: The Way the Air Moves
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- ambient
bpm: 87
key: Eb
image_jpg: /assets/covers/mute-reflex.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
