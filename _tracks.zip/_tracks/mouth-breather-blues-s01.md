---
layout: track
title: "Mouth Breather Blues S01"
permalink: /tracks/mouth-breather-blues-s01/
description: ""
image: "/assets/covers/mouth-breather-blues-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:19"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "ambient", "experimental electronic"]
bpm: 123
key: "E"
---

Explore more vibes in the [StudioRich track library](/tracks/).
