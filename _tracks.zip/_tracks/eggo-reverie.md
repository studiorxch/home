---
layout: track
title: "Eggo Reverie"
permalink: /tracks/eggo-reverie/
description: ""
image: "/assets/covers/eggo-reverie.webp"
image_ready: false
date: 2025-01-01
duration: "2:52"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "ambient", "cinematic"]
bpm: 120
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
