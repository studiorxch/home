---
layout: track
title: Neon With Teeth S01
permalink: /tracks/neon-with-teeth-s01/
description: ''
image: /assets/covers/neon-with-teeth-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:05'
album: The Way the Air Moves
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- ambient
bpm: 87
key: Eb
image_jpg: /assets/covers/neon-with-teeth-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
