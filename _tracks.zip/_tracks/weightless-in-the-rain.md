---
layout: track
title: "Weightless In The Rain"
permalink: /tracks/weightless-in-the-rain/
description: ""
image: "/assets/covers/weightless-in-the-rain.webp"
image_ready: false
date: 2025-01-01
duration: "2:12"
album: "Stranger Vibes"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi", "synthwave", "soul"]
bpm: 172
key: "B"
---

Explore more vibes in the [StudioRich track library](/tracks/).
