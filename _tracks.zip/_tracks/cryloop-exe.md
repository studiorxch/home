---
layout: track
title: Cryloop.exe
permalink: /tracks/cryloop-exe/
description: ''
image: /assets/covers/cryloop-exe.webp
image_ready: false
date: 2025-01-01
duration: '2:41'
album: The Way the Air Moves
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- experimental
bpm: 84
key: F#
image_jpg: /assets/covers/cryloop-exe.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
