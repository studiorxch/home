---
layout: track
title: Faster Than Goodbye
permalink: /tracks/faster-than-goodbye/
description: ''
image: /assets/covers/faster-than-goodbye.webp
image_ready: false
date: 2025-01-01
duration: '4:16'
album: Run Loop
mood:
- Tense
genre:
- hip-hop
- electronic
- ambient
bpm: 130
key: Eb
image_jpg: /assets/covers/faster-than-goodbye.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
