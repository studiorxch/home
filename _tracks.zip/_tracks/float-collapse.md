---
layout: track
title: "Float Collapse"
permalink: /tracks/float-collapse/
description: ""
image: "/assets/covers/float-collapse.webp"
image_ready: false
date: 2025-01-01
duration: "1:54"
album: "Stranger Vibes"
mood: ["Melancholy", "Dreamy", "Nostalgic"]
genre: ["lo-fi", "experimental", "ambient"]
bpm: 84
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
