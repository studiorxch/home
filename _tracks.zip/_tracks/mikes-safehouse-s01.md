---
layout: track
title: "Mikes Safehouse S01"
permalink: /tracks/mikes-safehouse-s01/
description: "Mikes Safehouse is a lo-fi, electronic, cinematic track — 132 BPM in E♭. Mood: tense, gritty. A cracked signal hidden behind analog static."
image: "/assets/covers/mikes-safehouse-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:37"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi", "electronic", "cinematic"]
bpm: 85
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
