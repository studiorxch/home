---
layout: track
title: Snowstatic
permalink: /tracks/snowstatic/
description: ''
image: /assets/covers/snowstatic.webp
image_ready: false
date: 2025-01-01
duration: '2:45'
album: The Way the Air Moves
mood:
- Energetic
- Aggressive
genre:
- lo-fi
- jungle
- ambient
bpm: 162
key: F#
image_jpg: /assets/covers/snowstatic.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
