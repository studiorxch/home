---
layout: track
title: "Crush.exe S1"
permalink: /tracks/crush-exe-s1/
description: ""
image: "/assets/covers/crush-exe-s1.webp"
image_ready: false
date: 2025-01-01
duration: "3:34"
album: "Run Loop"
mood: ["Chill"]
genre: ["electronic", "jungle", "glitch"]
bpm: 90
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
