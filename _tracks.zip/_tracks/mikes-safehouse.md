---
layout: track
title: "Mikes Safehouse"
permalink: /tracks/mikes-safehouse/
description: ""
image: "/assets/covers/mikes-safehouse.webp"
image_ready: false
date: 2025-01-01
duration: "2:41"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "electronic", "cinematic"]
bpm: 120
key: "B"
---

Explore more vibes in the [StudioRich track library](/tracks/).
