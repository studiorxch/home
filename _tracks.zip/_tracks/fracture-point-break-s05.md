---
layout: track
title: Fracture Point Break S05
permalink: /tracks/fracture-point-break-s05/
description: ''
image: /assets/covers/fracture-point-break-s05.webp
image_ready: false
date: 2025-01-01
duration: '2:28'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
- glitch-fusion
- experimental
bpm: 152
key: C
image_jpg: /assets/covers/fracture-point-break-s05.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
