---
layout: track
title: "Fracture Point Break S04"
permalink: /tracks/fracture-point-break-s04/
description: ""
image: "/assets/covers/fracture-point-break-s04.webp"
image_ready: false
date: 2025-01-01
duration: "2:54"
album: "Stranger Vibes"
mood: ["Dreamy", "Nostalgic"]
genre: ["lo-fi", "glitch-fusion"]
bpm: 88
key: "F"
---

Explore more vibes in the [StudioRich track library](/tracks/).
