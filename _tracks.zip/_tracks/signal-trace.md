---
layout: track
title: Signal Trace
permalink: /tracks/signal-trace/
description: ''
image: /assets/covers/signal-trace.webp
image_ready: false
date: 2025-01-01
duration: '1:48'
album: Run Loop
mood:
- Tense
genre:
- lo-fi
- experimental
- electronica
bpm: 129
key: F#
image_jpg: /assets/covers/signal-trace.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
