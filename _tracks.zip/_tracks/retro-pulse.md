---
layout: track
title: Retro Pulse
permalink: /tracks/retro-pulse/
description: ''
image: /assets/covers/retro-pulse.webp
image_ready: false
date: 2025-01-01
duration: '3:21'
album: Stranger Vibes
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- synthwave
bpm: 90
key: E
image_jpg: /assets/covers/retro-pulse.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
