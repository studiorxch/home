---
layout: track
title: Quiet Frequencies
permalink: /tracks/quiet-frequencies/
description: ''
image: /assets/covers/quiet-frequencies.webp
image_ready: false
date: 2025-01-01
duration: '2:16'
album: Stranger Vibes
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- synthwave
- soul
bpm: 88
key: D
image_jpg: /assets/covers/quiet-frequencies.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
