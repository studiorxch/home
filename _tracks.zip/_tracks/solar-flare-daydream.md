---
layout: track
title: Solar Flare Daydream
permalink: /tracks/solar-flare-daydream/
description: ''
image: /assets/covers/solar-flare-daydream.webp
image_ready: false
date: 2025-01-01
duration: '4:00'
album: Eunoia
mood:
- Tense
genre:
- ambient
- electronic
- experimental
bpm: 123
key: D
image_jpg: /assets/covers/solar-flare-daydream.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
