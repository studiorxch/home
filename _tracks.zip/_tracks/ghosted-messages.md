---
layout: track
title: "Ghosted Messages"
permalink: /tracks/ghosted-messages/
description: ""
image: "/assets/covers/ghosted-messages.webp"
image_ready: false
date: 2025-01-01
duration: "2:00"
album: "Run Loop"
mood: ["Melancholy"]
genre: ["trap", "r&b"]
bpm: 80
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
