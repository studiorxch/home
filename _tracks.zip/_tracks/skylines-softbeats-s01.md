---
layout: track
title: Skylines & Softbeats S01
permalink: /tracks/skylines-softbeats-s01/
description: ''
image: /assets/covers/skylines-softbeats-s01.webp
image_ready: false
date: 2025-01-01
duration: '3:16'
album: The Way the Air Moves
mood:
- Dreamy
- Nostalgic
genre:
- ambient
- lo-fi
- jungle
bpm: 92
key: F#
image_jpg: /assets/covers/skylines-softbeats-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
