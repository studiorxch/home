---
layout: track
title: Midnight Court
permalink: /tracks/midnight-court/
description: ''
image: /assets/covers/midnight-court.webp
image_ready: false
date: 2025-01-01
duration: '2:36'
album: Stranger Vibes
mood:
- Chill
genre:
- lo-fi hip hop
- jazztronica
- chillout
bpm: 90
key: Eb
image_jpg: /assets/covers/midnight-court.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
