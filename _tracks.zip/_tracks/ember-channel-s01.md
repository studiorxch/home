---
layout: track
title: Ember Channel S01
permalink: /tracks/ember-channel-s01/
description: ''
image: /assets/covers/ember-channel-s01.webp
image_ready: false
date: 2025-01-01
duration: '1:47'
album: The Way the Air Moves
mood:
- Chill
genre:
- ambient
- lo-fi
- jungle
bpm: 80
key: C#
image_jpg: /assets/covers/ember-channel-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
