---
layout: track
title: Feather Circuit
permalink: /tracks/feather-circuit/
description: ''
image: /assets/covers/feather-circuit.webp
image_ready: false
date: 2025-01-01
duration: '3:26'
album: The Way the Air Moves
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- cinematic
- lo-fi
- jungle
bpm: 85
key: Eb
image_jpg: /assets/covers/feather-circuit.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
