---
layout: track
title: "Static Memory"
permalink: /tracks/static-memory/
description: ""
image: "/assets/covers/static-memory.webp"
image_ready: false
date: 2025-01-01
duration: "2:27"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi", "synthwave", "ambient"]
bpm: 80
key: "D"
---

Explore more vibes in the [StudioRich track library](/tracks/).
