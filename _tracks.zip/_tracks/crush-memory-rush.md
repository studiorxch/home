---
layout: track
title: "Crush Memory Rush"
permalink: /tracks/crush-memory-rush/
description: ""
image: "/assets/covers/crush-memory-rush.webp"
image_ready: false
date: 2025-01-01
duration: "5:14"
album: "Run Loop"
mood: ["Chill"]
genre: ["jungle", "r&b", "ambient"]
bpm: 87
key: "B"
---

Explore more vibes in the [StudioRich track library](/tracks/).
