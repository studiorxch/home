---
layout: track
title: "Radiant Brake"
permalink: /tracks/radiant-brake/
description: ""
image: "/assets/covers/radiant-brake.webp"
image_ready: false
date: 2025-01-01
duration: "2:38"
album: "The Way the Air Moves"
mood: ["Energetic", "Aggressive"]
genre: ["cinematic", "lo-fi", "jungle"]
bpm: 161
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
