---
layout: track
title: "Light from a Distance"
permalink: /tracks/light-from-a-distance/
description: ""
image: "/assets/covers/light-from-a-distance.webp"
image_ready: false
date: 2025-01-01
duration: "2:28"
album: "Run Loop"
mood: []
genre: ["ambient", "minimal"]
bpm: 135
key: "E"
---

Explore more vibes in the [StudioRich track library](/tracks/).
