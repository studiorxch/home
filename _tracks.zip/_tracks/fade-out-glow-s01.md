---
layout: track
title: "Fade Out Glow S01"
permalink: /tracks/fade-out-glow-s01/
description: ""
image: "/assets/covers/fade-out-glow-s01.webp"
image_ready: false
date: 2025-01-01
duration: "1:50"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi", "downtempo", "chillhop"]
bpm: 85
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
