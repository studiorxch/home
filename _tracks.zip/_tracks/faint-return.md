---
layout: track
title: "Faint Return"
permalink: /tracks/faint-return/
description: ""
image: "/assets/covers/faint-return.webp"
image_ready: false
date: 2025-01-01
duration: "2:17"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "electronic"]
bpm: 88
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
