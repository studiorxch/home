---
layout: track
title: "Light Rewind S03"
permalink: /tracks/light-rewind-s03/
description: ""
image: "/assets/covers/light-rewind-s03.webp"
image_ready: false
date: 2025-01-01
duration: "1:47"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi", "chillhop", "soul"]
bpm: 80
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
