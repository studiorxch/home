---
layout: track
title: Empty Hall Echo S01
permalink: /tracks/empty-hall-echo-s01/
description: ''
image: /assets/covers/empty-hall-echo-s01.webp
image_ready: false
date: 2025-01-01
duration: '1:33'
album: Stranger Vibes
mood:
- Hopeful
genre:
- lo-fi
- ambient
- experimental
bpm: 112
key: Ab
image_jpg: /assets/covers/empty-hall-echo-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
