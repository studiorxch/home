---
layout: track
title: "Ghost Loop"
permalink: /tracks/ghost-loop/
description: ""
image: "/assets/covers/ghost-loop.webp"
image_ready: false
date: 2025-01-01
duration: "4:36"
album: "Run Loop"
mood: []
genre: ["ambient", "experimental"]
bpm: 135
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
