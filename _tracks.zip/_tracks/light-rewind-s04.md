---
layout: track
title: Light Rewind S04
permalink: /tracks/light-rewind-s04/
description: ''
image: /assets/covers/light-rewind-s04.webp
image_ready: false
date: 2025-01-01
duration: '2:27'
album: Stranger Vibes
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- chillhop
- soul
bpm: 84
key: Bb
image_jpg: /assets/covers/light-rewind-s04.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
