---
layout: track
title: "Infinite Vistas"
permalink: /tracks/infinite-vistas/
description: ""
image: "/assets/covers/infinite-vistas.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Eunoia"
mood: []
genre: ["ambient", "electronic", "experimental"]
bpm: 120
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
