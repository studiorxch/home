---
layout: track
title: Last Scene In Shadows
permalink: /tracks/last-scene-in-shadows/
description: ''
image: /assets/covers/last-scene-in-shadows.webp
image_ready: false
date: 2025-01-01
duration: '2:47'
album: Stranger Vibes
mood:
- Melancholy
genre:
- lo-fi hip hop
- downtempo
- chillhop
bpm: 80
key: B
image_jpg: /assets/covers/last-scene-in-shadows.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
