---
layout: track
title: "Glide Memory S01"
permalink: /tracks/glide-memory-s01/
description: ""
image: "/assets/covers/glide-memory-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:42"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 80
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
