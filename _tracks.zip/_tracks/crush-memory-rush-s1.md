---
layout: track
title: Crush Memory Rush S1
permalink: /tracks/crush-memory-rush-s1/
description: ''
image: /assets/covers/crush-memory-rush-s1.webp
image_ready: false
date: 2025-01-01
duration: '4:37'
album: Run Loop
mood:
- Chill
genre:
- jungle
- r&b
- ambient
bpm: 83
key: Eb
image_jpg: /assets/covers/crush-memory-rush-s1.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
