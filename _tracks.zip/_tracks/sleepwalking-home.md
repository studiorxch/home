---
layout: track
title: Sleepwalking Home
permalink: /tracks/sleepwalking-home/
description: ''
image: /assets/covers/sleepwalking-home.webp
image_ready: false
date: 2025-01-01
duration: '3:02'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
- ambient
- chillhop
bpm: 150
key: B
image_jpg: /assets/covers/sleepwalking-home.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
