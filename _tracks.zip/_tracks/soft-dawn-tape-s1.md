---
layout: track
title: "Soft Dawn Tape S1"
permalink: /tracks/soft-dawn-tape-s1/
description: ""
image: "/assets/covers/soft-dawn-tape-s1.webp"
image_ready: false
date: 2025-01-01
duration: "6:54"
album: "Run Loop"
mood: ["Energetic", "Aggressive"]
genre: ["ambient", "experimental"]
bpm: 163
key: "B"
---

Explore more vibes in the [StudioRich track library](/tracks/).
