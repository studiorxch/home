---
layout: track
title: Lucas Loop S03
permalink: /tracks/lucas-loop-s03/
description: ''
image: /assets/covers/lucas-loop-s03.webp
image_ready: false
date: 2025-01-01
duration: '1:35'
album: Stranger Vibes
mood: []
genre:
- lo-fi
- chillhop
- ambient
bpm: 136
key: B
image_jpg: /assets/covers/lucas-loop-s03.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
