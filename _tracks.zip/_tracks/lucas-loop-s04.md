---
layout: track
title: Lucas Loop S04
permalink: /tracks/lucas-loop-s04/
description: ''
image: /assets/covers/lucas-loop-s04.webp
image_ready: false
date: 2025-01-01
duration: '3:02'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
- chillhop
- ambient
bpm: 145
key: F#
image_jpg: /assets/covers/lucas-loop-s04.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
