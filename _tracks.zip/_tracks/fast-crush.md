---
layout: track
title: "Fast Crush"
permalink: /tracks/fast-crush/
description: ""
image: "/assets/covers/fast-crush.webp"
image_ready: false
date: 2025-01-01
duration: "3:15"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 80
key: "A"
---

Explore more vibes in the [StudioRich track library](/tracks/).
