---
layout: track
title: 160 and Holding
permalink: /tracks/160-and-holding/
description: ''
image: /assets/covers/160-and-holding.webp
image_ready: false
date: 2025-01-01
duration: '2:57'
album: The Way the Air Moves
mood:
- Hopeful
genre:
- lo-fi
- jungle
- ambient
bpm: 118
key: Eb
image_jpg: /assets/covers/160-and-holding.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
