---
layout: track
title: Love Error 1997
permalink: /tracks/love-error-1997/
description: ''
image: /assets/covers/love-error-1997.webp
image_ready: false
date: 2025-01-01
duration: '3:36'
album: Run Loop
mood:
- Melancholy
genre:
- jungle
- experimental electronic
bpm: 78
key: C#
image_jpg: /assets/covers/love-error-1997.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
