---
layout: track
title: "Walkie Crackle"
permalink: /tracks/walkie-crackle/
description: ""
image: "/assets/covers/walkie-crackle.webp"
image_ready: false
date: 2025-01-01
duration: "1:53"
album: "Stranger Vibes"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi", "swing", "cinematic"]
bpm: 172
key: "F"
---

Explore more vibes in the [StudioRich track library](/tracks/).
