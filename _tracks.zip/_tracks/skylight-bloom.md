---
layout: track
title: Skylight Bloom
permalink: /tracks/skylight-bloom/
description: ''
image: /assets/covers/skylight-bloom.webp
image_ready: false
date: 2025-01-01
duration: '2:20'
album: The Way the Air Moves
mood:
- Chill
genre:
- lo-fi
- jungle
- electronic
bpm: 89
key: Bb
image_jpg: /assets/covers/skylight-bloom.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
