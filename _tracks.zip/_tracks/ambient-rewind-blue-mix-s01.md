---
layout: track
title: Ambient Rewind Blue Mix S01
permalink: /tracks/ambient-rewind-blue-mix-s01/
description: ''
image: /assets/covers/ambient-rewind-blue-mix-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:28'
album: Run Loop
mood:
- Playful
genre:
- lo-fi
- instrumental
- ambient
bpm: 90
key: D
image_jpg: /assets/covers/ambient-rewind-blue-mix-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
