---
layout: track
title: Static Panorama
permalink: /tracks/static-panorama/
description: ''
image: /assets/covers/static-panorama.webp
image_ready: false
date: 2025-01-01
duration: '4:00'
album: Eunoia
mood:
- Energetic
- Aggressive
genre:
- ambient
- electronic
- experimental
bpm: 164
key: D
image_jpg: /assets/covers/static-panorama.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
