---
layout: track
title: "Air Between Us S01"
permalink: /tracks/air-between-us-s01/
description: ""
image: "/assets/covers/air-between-us-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:26"
album: "The Way the Air Moves"
mood: ["Dreamy", "Nostalgic"]
genre: ["lo-fi", "jungle", "soulful"]
bpm: 89
key: "B"
---

Explore more vibes in the [StudioRich track library](/tracks/).
