---
layout: track
title: Float Trigger
permalink: /tracks/float-trigger/
description: ''
image: /assets/covers/float-trigger.webp
image_ready: false
date: 2025-01-01
duration: '2:17'
album: The Way the Air Moves
mood:
- Chill
genre:
- lo-fi
- jungle
- electronic
bpm: 85
key: E
image_jpg: /assets/covers/float-trigger.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
