---
layout: track
title: "Quiet Leaves S01"
permalink: /tracks/quiet-leaves-s01/
description: ""
image: "/assets/covers/quiet-leaves-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:27"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "electronic", "cinematic"]
bpm: 130
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
