---
layout: track
title: "Scout's Promise S02"
permalink: /tracks/scouts-promise-s02/
description: ""
image: "/assets/covers/scouts-promise-s02.webp"
image_ready: false
date: 2025-01-01
duration: "2:10"
album: "Stranger Vibes"
mood: ["Aggressive"]
genre: ["lo-fi", "chillhop", "electronic"]
bpm: 145
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
