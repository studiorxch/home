---
layout: track
title: "Phantom Tapestry"
permalink: /tracks/phantom-tapestry/
description: ""
image: "/assets/covers/phantom-tapestry.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Eunoia"
mood: []
genre: ["ambient", "electronic", "experimental"]
bpm: 128
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
