---
layout: track
title: Drift Tempo S01
permalink: /tracks/drift-tempo-s01/
description: ''
image: /assets/covers/drift-tempo-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:49'
album: The Way the Air Moves
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- piano
bpm: 87
key: B
image_jpg: /assets/covers/drift-tempo-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
