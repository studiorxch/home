---
layout: track
title: Arcade Roms
permalink: /tracks/arcade-roms/
description: ''
image: /assets/covers/arcade-roms.webp
image_ready: false
date: 2025-01-01
duration: '3:00'
album: Stranger Vibes
mood:
- Chill
genre:
- lo-fi
- swing
- cinematic
bpm: 80
key: D
image_jpg: /assets/covers/arcade-roms.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
