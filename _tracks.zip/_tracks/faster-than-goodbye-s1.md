---
layout: track
title: "Faster Than Goodbye S1"
permalink: /tracks/faster-than-goodbye-s1/
description: ""
image: "/assets/covers/faster-than-goodbye-s1.webp"
image_ready: false
date: 2025-01-01
duration: "2:52"
album: "Run Loop"
mood: ["Playful"]
genre: ["hip-hop", "electronic", "ambient"]
bpm: 98
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
