---
layout: track
title: "Luminous Fade"
permalink: /tracks/luminous-fade/
description: ""
image: "/assets/covers/luminous-fade.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Eunoia"
mood: ["Hopeful"]
genre: ["ambient", "electronic", "experimental"]
bpm: 120
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
