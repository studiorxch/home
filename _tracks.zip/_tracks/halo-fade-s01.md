---
layout: track
title: Halo Fade S01
permalink: /tracks/halo-fade-s01/
description: ''
image: /assets/covers/halo-fade-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:58'
album: The Way the Air Moves
mood:
- Aggressive
genre:
- lo-fi
- jungle
- soul
bpm: 150
key: G
image_jpg: /assets/covers/halo-fade-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
