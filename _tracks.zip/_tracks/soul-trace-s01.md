---
layout: track
title: Soul Trace S01
permalink: /tracks/soul-trace-s01/
description: ''
image: /assets/covers/soul-trace-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:21'
album: The Way the Air Moves
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- soul
bpm: 84
key: Bb
image_jpg: /assets/covers/soul-trace-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
