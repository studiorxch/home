---
layout: track
title: Roll Call S04
permalink: /tracks/roll-call-s04/
description: ''
image: /assets/covers/roll-call-s04.webp
image_ready: false
date: 2025-01-01
duration: '1:47'
album: Stranger Vibes
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- indie
- chill
bpm: 85
key: Eb
image_jpg: /assets/covers/roll-call-s04.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
