---
layout: track
title: "Lo Pulse"
permalink: /tracks/lo-pulse/
description: ""
image: "/assets/covers/lo-pulse.webp"
image_ready: false
date: 2025-01-01
duration: "2:23"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 80
key: "E"
---

Explore more vibes in the [StudioRich track library](/tracks/).
