---
layout: track
title: Lo Pulse S01
permalink: /tracks/lo-pulse-s01/
description: ''
image: /assets/covers/lo-pulse-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:09'
album: The Way the Air Moves
mood:
- Chill
genre:
- lo-fi
- jungle
- ambient
bpm: 85
key: F#
image_jpg: /assets/covers/lo-pulse-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
