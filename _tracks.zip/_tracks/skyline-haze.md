---
layout: track
title: "Skyline Haze"
permalink: /tracks/skyline-haze/
description: ""
image: "/assets/covers/skyline-haze.webp"
image_ready: false
date: 2025-01-01
duration: "2:49"
album: "Eunoia"
mood: ["Aggressive"]
genre: ["ambient", "electronic", "experimental"]
bpm: 148
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
