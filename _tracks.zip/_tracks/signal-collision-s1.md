---
layout: track
title: "Signal Collision S1"
permalink: /tracks/signal-collision-s1/
description: ""
image: "/assets/covers/signal-collision-s1.webp"
image_ready: false
date: 2025-01-01
duration: "7:57"
album: "Run Loop"
mood: ["Melancholy", "Dreamy", "Nostalgic"]
genre: ["electronic", "experimental", "post-rock"]
bpm: 82
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
