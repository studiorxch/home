---
layout: track
title: Chrono Horizon
permalink: /tracks/chrono-horizon/
description: ''
image: /assets/covers/chrono-horizon.webp
image_ready: false
date: 2025-01-01
duration: '4:00'
album: Eunoia
mood:
- Hopeful
genre:
- ambient
- electronic
- experimental
bpm: 120
key: Ab
image_jpg: /assets/covers/chrono-horizon.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
