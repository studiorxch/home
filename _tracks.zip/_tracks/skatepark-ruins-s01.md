---
layout: track
title: "Skatepark Ruins S01"
permalink: /tracks/skatepark-ruins-s01/
description: ""
image: "/assets/covers/skatepark-ruins-s01.webp"
image_ready: false
date: 2025-01-01
duration: "1:54"
album: "Stranger Vibes"
mood: ["Hopeful"]
genre: ["lo-fi", "experimental", "melancholic"]
bpm: 118
key: "F"
---

Explore more vibes in the [StudioRich track library](/tracks/).
