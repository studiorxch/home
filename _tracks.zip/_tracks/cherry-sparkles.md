---
layout: track
title: Cherry Sparkles
permalink: /tracks/cherry-sparkles/
description: ''
image: /assets/covers/cherry-sparkles.webp
image_ready: false
date: 2025-01-01
duration: '2:00'
album: Stranger Vibes
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
bpm: 80
key: A
image_jpg: /assets/covers/cherry-sparkles.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
