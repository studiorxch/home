---
layout: track
title: Before the First Word S1
permalink: /tracks/before-the-first-word-s1/
description: ''
image: /assets/covers/before-the-first-word-s1.webp
image_ready: false
date: 2025-01-01
duration: '2:21'
album: Run Loop
mood:
- Dreamy
genre:
- ambient
- electronic
- downtempo
bpm: 100
key: A
image_jpg: /assets/covers/before-the-first-word-s1.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
