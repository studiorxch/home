---
layout: track
title: 160 and Holding S01
permalink: /tracks/160-and-holding-s01/
description: ''
image: /assets/covers/160-and-holding-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:05'
album: The Way the Air Moves
mood: []
genre:
- lo-fi
- jungle
- ambient
bpm: 138
key: F#
image_jpg: /assets/covers/160-and-holding-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
