---
layout: track
title: "Memory Drip S01"
permalink: /tracks/memory-drip-s01/
description: ""
image: "/assets/covers/memory-drip-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:49"
album: "The Way the Air Moves"
mood: ["Melancholy", "Dreamy", "Nostalgic"]
genre: ["lo-fi", "jungle", "electronic"]
bpm: 85
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
