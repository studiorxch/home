---
layout: track
title: "Mute Reflex S01"
permalink: /tracks/mute-reflex-s01/
description: ""
image: "/assets/covers/mute-reflex-s01.webp"
image_ready: false
date: 2025-01-01
duration: "4:27"
album: "The Way the Air Moves"
mood: ["Dreamy", "Nostalgic"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 87
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
