---
layout: track
title: "Before the First Word"
permalink: /tracks/before-the-first-word/
description: ""
image: "/assets/covers/before-the-first-word.webp"
image_ready: false
date: 2025-01-01
duration: "3:20"
album: "Run Loop"
mood: ["Hopeful"]
genre: ["ambient", "electronic", "downtempo"]
bpm: 120
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
