---
layout: track
title: "Letters Left"
permalink: /tracks/letters-left/
description: ""
image: "/assets/covers/letters-left.webp"
image_ready: false
date: 2025-01-01
duration: "2:52"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi", "indie", "bedroom pop"]
bpm: 80
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
