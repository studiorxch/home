---
layout: track
title: Float Trigger S01
permalink: /tracks/float-trigger-s01/
description: ''
image: /assets/covers/float-trigger-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:35'
album: The Way the Air Moves
mood:
- Chill
genre:
- lo-fi
- jungle
- electronic
bpm: 86
key: C
image_jpg: /assets/covers/float-trigger-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
