---
layout: track
title: "Near Her Window"
permalink: /tracks/near-her-window/
description: ""
image: "/assets/covers/near-her-window.webp"
image_ready: false
date: 2025-01-01
duration: "3:35"
album: "Run Loop"
mood: ["Hopeful", "Playful"]
genre: ["ambient", "electronic"]
bpm: 104
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
