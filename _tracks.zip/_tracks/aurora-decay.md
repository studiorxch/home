---
layout: track
title: "Aurora Decay"
permalink: /tracks/aurora-decay/
description: ""
image: "/assets/covers/aurora-decay.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Eunoia"
mood: ["Dreamy"]
genre: ["ambient", "electronic", "experimental"]
bpm: 104
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
