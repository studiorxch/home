---
layout: track
title: Glass Transit
permalink: /tracks/glass-transit/
description: ''
image: /assets/covers/glass-transit.webp
image_ready: false
date: 2025-01-01
duration: '2:13'
album: The Way the Air Moves
mood:
- Melancholy
genre:
- lo-fi
- jungle
- experimental
bpm: 72
key: E
image_jpg: /assets/covers/glass-transit.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
