---
layout: track
title: "Pulse Petals"
permalink: /tracks/pulse-petals/
description: ""
image: "/assets/covers/pulse-petals.webp"
image_ready: false
date: 2025-01-01
duration: "2:44"
album: "The Way the Air Moves"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 162
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
