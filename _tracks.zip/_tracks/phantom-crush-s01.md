---
layout: track
title: "Phantom Crush S01"
permalink: /tracks/phantom-crush-s01/
description: ""
image: "/assets/covers/phantom-crush-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:21"
album: "The Way the Air Moves"
mood: ["Dreamy", "Nostalgic"]
genre: ["lo-fi", "jungle", "electronic"]
bpm: 88
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
