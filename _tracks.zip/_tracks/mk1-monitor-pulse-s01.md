---
layout: track
title: "Mk1 Monitor Pulse S01"
permalink: /tracks/mk1-monitor-pulse-s01/
description: ""
image: "/assets/covers/mk1-monitor-pulse-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:28"
album: "Stranger Vibes"
mood: ["Playful"]
genre: ["lo-fi", "industrial", "chillhop"]
bpm: 92
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
