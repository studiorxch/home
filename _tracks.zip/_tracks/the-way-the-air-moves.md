---
layout: track
title: The Way the Air Moves
permalink: /tracks/the-way-the-air-moves/
description: ''
image: /assets/covers/the-way-the-air-moves.webp
image_ready: false
date: 2025-01-01
duration: '2:12'
album: The Way the Air Moves
mood:
- Chill
genre:
- lo-fi
- jungle
- ambient
bpm: 88
key: F#
image_jpg: /assets/covers/the-way-the-air-moves.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
