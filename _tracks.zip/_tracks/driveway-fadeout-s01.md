---
layout: track
title: "Driveway Fadeout S01"
permalink: /tracks/driveway-fadeout-s01/
description: ""
image: "/assets/covers/driveway-fadeout-s01.webp"
image_ready: false
date: 2025-01-01
duration: "1:31"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi", "glitch", "electronic"]
bpm: 83
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
