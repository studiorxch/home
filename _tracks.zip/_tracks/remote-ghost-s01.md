---
layout: track
title: Remote Ghost S01
permalink: /tracks/remote-ghost-s01/
description: ''
image: /assets/covers/remote-ghost-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:15'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
- dream pop
- ambient
bpm: 140
key: Bb
image_jpg: /assets/covers/remote-ghost-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
