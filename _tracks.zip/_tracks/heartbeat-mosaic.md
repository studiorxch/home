---
layout: track
title: "Heartbeat Mosaic"
permalink: /tracks/heartbeat-mosaic/
description: ""
image: "/assets/covers/heartbeat-mosaic.webp"
image_ready: false
date: 2025-01-01
duration: "2:39"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 87
key: "D"
---

Explore more vibes in the [StudioRich track library](/tracks/).
