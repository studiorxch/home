---
layout: track
title: Pulse in the Haze S03
permalink: /tracks/pulse-in-the-haze-s03/
description: ''
image: /assets/covers/pulse-in-the-haze-s03.webp
image_ready: false
date: 2025-01-01
duration: '3:09'
album: The Way the Air Moves
mood:
- Energetic
- Aggressive
genre:
- lo-fi
- jungle
- ambient
bpm: 162
key: Eb
image_jpg: /assets/covers/pulse-in-the-haze-s03.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
