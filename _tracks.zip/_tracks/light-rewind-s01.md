---
layout: track
title: Light Rewind S01
permalink: /tracks/light-rewind-s01/
description: ''
image: /assets/covers/light-rewind-s01.webp
image_ready: false
date: 2025-01-01
duration: '3:05'
album: Stranger Vibes
mood:
- Playful
genre:
- lo-fi
- chillhop
- soul
bpm: 99
key: F
image_jpg: /assets/covers/light-rewind-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
