---
layout: track
title: "Quiet Geometry S01"
permalink: /tracks/quiet-geometry-s01/
description: ""
image: "/assets/covers/quiet-geometry-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:14"
album: "The Way the Air Moves"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi", "jungle", "instrumental"]
bpm: 162
key: "A"
---

Explore more vibes in the [StudioRich track library](/tracks/).
