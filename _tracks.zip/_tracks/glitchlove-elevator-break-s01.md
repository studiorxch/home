---
layout: track
title: Glitchlove Elevator Break S01
permalink: /tracks/glitchlove-elevator-break-s01/
description: ''
image: /assets/covers/glitchlove-elevator-break-s01.webp
image_ready: false
date: 2025-01-01
duration: '4:31'
album: Run Loop
mood:
- Dreamy
- Nostalgic
genre:
- drum and bass
- electronic
bpm: 86
key: F
image_jpg: /assets/covers/glitchlove-elevator-break-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
