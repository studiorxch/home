---
layout: track
title: "Glitchlove Elevator Break"
permalink: /tracks/glitchlove-elevator-break/
description: ""
image: "/assets/covers/glitchlove-elevator-break.webp"
image_ready: false
date: 2025-01-01
duration: "4:25"
album: "Run Loop"
mood: ["Dreamy", "Nostalgic"]
genre: ["drum and bass", "electronic"]
bpm: 87
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
