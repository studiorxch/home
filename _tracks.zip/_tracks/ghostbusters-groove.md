---
layout: track
title: "Ghostbusters Groove"
permalink: /tracks/ghostbusters-groove/
description: ""
image: "/assets/covers/ghostbusters-groove.webp"
image_ready: false
date: 2025-01-01
duration: "2:45"
album: "Stranger Vibes"
mood: ["Aggressive"]
genre: ["lo-fi", "cinematic", "ambient"]
bpm: 146
key: "A"
---

Explore more vibes in the [StudioRich track library](/tracks/).
