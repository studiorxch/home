---
layout: track
title: "Glass Drift"
permalink: /tracks/glass-drift/
description: ""
image: "/assets/covers/glass-drift.webp"
image_ready: false
date: 2025-01-01
duration: "2:24"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "electronic"]
bpm: 90
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
