---
layout: track
title: Light Rewind S02
permalink: /tracks/light-rewind-s02/
description: ''
image: /assets/covers/light-rewind-s02.webp
image_ready: false
date: 2025-01-01
duration: '1:35'
album: Stranger Vibes
mood:
- Hopeful
- Playful
genre:
- lo-fi
- chillhop
- soul
bpm: 100
key: F
image_jpg: /assets/covers/light-rewind-s02.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
