---
layout: track
title: Winning Shot
permalink: /tracks/winning-shot/
description: ''
image: /assets/covers/winning-shot.webp
image_ready: false
date: 2025-01-01
duration: '2:33'
album: Stranger Vibes
mood:
- Playful
genre:
- lo-fi
- hip-hop
- electronic
bpm: 94
key: Bb
image_jpg: /assets/covers/winning-shot.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
