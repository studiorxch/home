---
layout: track
title: Echoes Of Nostalgia
permalink: /tracks/echoes-of-nostalgia/
description: ''
image: /assets/covers/echoes-of-nostalgia.webp
image_ready: false
date: 2025-01-01
duration: '4:00'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
bpm: 142
key: G
image_jpg: /assets/covers/echoes-of-nostalgia.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
