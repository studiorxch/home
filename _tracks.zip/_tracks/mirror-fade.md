---
layout: track
title: Mirror Fade
permalink: /tracks/mirror-fade/
description: ''
image: /assets/covers/mirror-fade.webp
image_ready: false
date: 2025-01-01
duration: '3:54'
album: Run Loop
mood: []
genre:
- breakbeat
- nostalgic
- guitar-driven
bpm: 124
key: C
image_jpg: /assets/covers/mirror-fade.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
