---
layout: track
title: Echo Float S01
permalink: /tracks/echo-float-s01/
description: ''
image: /assets/covers/echo-float-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:39'
album: The Way the Air Moves
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- dream pop
bpm: 85
key: Ab
image_jpg: /assets/covers/echo-float-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
