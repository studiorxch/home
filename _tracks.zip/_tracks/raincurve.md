---
layout: track
title: Raincurve
permalink: /tracks/raincurve/
description: ''
image: /assets/covers/raincurve.webp
image_ready: false
date: 2025-01-01
duration: '1:48'
album: The Way the Air Moves
mood:
- Chill
genre:
- lo-fi
- jungle
- dream pop
bpm: 87
key: A
image_jpg: /assets/covers/raincurve.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
