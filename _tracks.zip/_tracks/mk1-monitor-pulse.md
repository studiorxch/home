---
layout: track
title: "Mk1 Monitor Pulse"
permalink: /tracks/mk1-monitor-pulse/
description: ""
image: "/assets/covers/mk1-monitor-pulse.webp"
image_ready: false
date: 2025-01-01
duration: "2:12"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "industrial", "chillhop"]
bpm: 135
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
