---
layout: track
title: Altocumulus
permalink: /tracks/altocumulus/
description: ''
image: /assets/covers/altocumulus.webp
image_ready: false
date: 2025-01-01
duration: '2:04'
album: The Way the Air Moves
mood:
- Chill
genre:
- lo-fi
- jungle
- dream pop
bpm: 85
key: G
image_jpg: /assets/covers/altocumulus.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
