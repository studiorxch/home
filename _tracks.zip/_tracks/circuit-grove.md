---
layout: track
title: "Circuit Grove"
permalink: /tracks/circuit-grove/
description: ""
image: "/assets/covers/circuit-grove.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Eunoia"
mood: []
genre: ["ambient", "electronic", "experimental"]
bpm: 139
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
