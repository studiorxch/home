---
layout: track
title: Solo Stand S02
permalink: /tracks/solo-stand-s02/
description: ''
image: /assets/covers/solo-stand-s02.webp
image_ready: false
date: 2025-01-01
duration: '2:05'
album: Stranger Vibes
mood:
- Chill
genre:
- lo-fi
- chillhop
- cinematic
bpm: 81
key: D
image_jpg: /assets/covers/solo-stand-s02.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
