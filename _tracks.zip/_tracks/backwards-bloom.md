---
layout: track
title: Backwards Bloom
permalink: /tracks/backwards-bloom/
description: ''
image: /assets/covers/backwards-bloom.webp
image_ready: true
date: 2025-01-01
duration: '3:33'
album: Stranger Vibes
mood:
- Tense
genre:
- ambient
- electronic
- experimental
bpm: 129
key: C#
image_jpg: /assets/covers/backwards-bloom.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
