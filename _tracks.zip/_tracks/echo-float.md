---
layout: track
title: "Echo Float"
permalink: /tracks/echo-float/
description: ""
image: "/assets/covers/echo-float.webp"
image_ready: false
date: 2025-01-01
duration: "3:01"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "dream pop"]
bpm: 80
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
