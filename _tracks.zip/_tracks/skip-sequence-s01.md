---
layout: track
title: Skip Sequence S01
permalink: /tracks/skip-sequence-s01/
description: ''
image: /assets/covers/skip-sequence-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:58'
album: The Way the Air Moves
mood:
- Dreamy
- Nostalgic
genre:
- ambient
- lo-fi
- jungle
bpm: 87
key: F#
image_jpg: /assets/covers/skip-sequence-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
