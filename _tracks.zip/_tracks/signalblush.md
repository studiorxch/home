---
layout: track
title: "Signalblush"
permalink: /tracks/signalblush/
description: ""
image: "/assets/covers/signalblush.webp"
image_ready: false
date: 2025-01-01
duration: "2:42"
album: "The Way the Air Moves"
mood: ["Tense"]
genre: ["ambient", "lo-fi", "dub"]
bpm: 129
key: "B"
---

Explore more vibes in the [StudioRich track library](/tracks/).
