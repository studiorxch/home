---
layout: track
title: Glide Memory
permalink: /tracks/glide-memory/
description: ''
image: /assets/covers/glide-memory.webp
image_ready: false
date: 2025-01-01
duration: '2:12'
album: The Way the Air Moves
mood:
- Energetic
- Aggressive
genre:
- lo-fi
- jungle
- ambient
bpm: 172
key: F#
image_jpg: /assets/covers/glide-memory.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
