---
layout: track
title: Forest Rhythms
permalink: /tracks/forest-rhythms/
description: ''
image: /assets/covers/forest-rhythms.webp
image_ready: false
date: 2025-01-01
duration: '1:38'
album: Stranger Vibes
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
bpm: 83
key: E
image_jpg: /assets/covers/forest-rhythms.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
