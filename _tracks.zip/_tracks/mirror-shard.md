---
layout: track
title: "Mirror Shard"
permalink: /tracks/mirror-shard/
description: "Mirror Shard is a Chill, Dreamy, Gritty, Nostalgic track blending lo-fi, experimental, ambient with sleep energy."
image: "/assets/covers/mirror-shard.webp"
image_ready: false
date: 2025-01-01
duration: "2:25"
album: "Stranger Vibes"
mood: ["Dreamy", "Nostalgic"]
genre: ["lo-fi", "experimental", "ambient"]
bpm: 86
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
