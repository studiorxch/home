---
layout: track
title: Floating Through Her Street S1
permalink: /tracks/floating-through-her-street-s1/
description: ''
image: /assets/covers/floating-through-her-street-s1.webp
image_ready: false
date: 2025-01-01
duration: '3:01'
album: Run Loop
mood:
- Dreamy
- Nostalgic
genre:
- ambient
- downtempo
bpm: 90
key: F#
image_jpg: /assets/covers/floating-through-her-street-s1.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
