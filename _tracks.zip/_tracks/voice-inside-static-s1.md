---
layout: track
title: "Voice Inside Static S1"
permalink: /tracks/voice-inside-static-s1/
description: ""
image: "/assets/covers/voice-inside-static-s1.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Run Loop"
mood: ["Dreamy", "Nostalgic"]
genre: ["ambient", "jungle", "dream pop"]
bpm: 88
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
