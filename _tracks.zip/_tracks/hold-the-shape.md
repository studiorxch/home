---
layout: track
title: Hold The Shape
permalink: /tracks/hold-the-shape/
description: ''
image: /assets/covers/hold-the-shape.webp
image_ready: false
date: 2025-01-01
duration: '3:56'
album: Run Loop
mood:
- Energetic
- Aggressive
genre:
- jungle
- ambient
bpm: 172
key: G
image_jpg: /assets/covers/hold-the-shape.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
