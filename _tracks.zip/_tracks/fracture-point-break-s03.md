---
layout: track
title: Fracture Point Break S03
permalink: /tracks/fracture-point-break-s03/
description: ''
image: /assets/covers/fracture-point-break-s03.webp
image_ready: false
date: 2025-01-01
duration: '2:11'
album: Stranger Vibes
mood:
- Chill
genre:
- lo-fi
- glitch-fusion
bpm: 74
key: D
image_jpg: /assets/covers/fracture-point-break-s03.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
