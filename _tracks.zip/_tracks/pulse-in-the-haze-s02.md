---
layout: track
title: "Pulse in the Haze S02"
permalink: /tracks/pulse-in-the-haze-s02/
description: ""
image: "/assets/covers/pulse-in-the-haze-s02.webp"
image_ready: false
date: 2025-01-01
duration: "2:12"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 80
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
