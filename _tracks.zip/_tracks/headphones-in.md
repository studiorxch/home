---
layout: track
title: Headphones In
permalink: /tracks/headphones-in/
description: ''
image: /assets/covers/headphones-in.webp
image_ready: false
date: 2025-01-01
duration: '2:42'
album: Stranger Vibes
mood:
- Hopeful
genre:
- lo-fi
- ambient
- chillwave
bpm: 118
key: D
image_jpg: /assets/covers/headphones-in.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
