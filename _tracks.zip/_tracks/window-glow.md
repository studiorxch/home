---
layout: track
title: "Window Glow"
permalink: /tracks/window-glow/
description: ""
image: "/assets/covers/window-glow.webp"
image_ready: false
date: 2025-01-01
duration: "1:35"
album: "Run Loop"
mood: ["Chill"]
genre: ["lo-fi", "r&b", "ambient"]
bpm: 80
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
