---
layout: track
title: Phantom Crush S04
permalink: /tracks/phantom-crush-s04/
description: ''
image: /assets/covers/phantom-crush-s04.webp
image_ready: false
date: 2025-01-01
duration: '1:51'
album: The Way the Air Moves
mood:
- Chill
genre:
- cinematic
- lo-fi
- jungle
bpm: 86
key: F#
image_jpg: /assets/covers/phantom-crush-s04.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
