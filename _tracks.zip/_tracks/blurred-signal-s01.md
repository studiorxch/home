---
layout: track
title: "Blurred Signal S01"
permalink: /tracks/blurred-signal-s01/
description: ""
image: "/assets/covers/blurred-signal-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:15"
album: "The Way the Air Moves"
mood: ["Melancholy", "Dreamy", "Nostalgic"]
genre: ["lo-fi", "jungle", "nostalgic"]
bpm: 85
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
