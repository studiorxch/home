---
layout: track
title: Solo Stand
permalink: /tracks/solo-stand/
description: ''
image: /assets/covers/solo-stand.webp
image_ready: false
date: 2025-01-01
duration: '3:22'
album: Stranger Vibes
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- chillhop
- cinematic
bpm: 85
key: D
image_jpg: /assets/covers/solo-stand.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
