---
layout: track
title: Softcore Velocity S01
permalink: /tracks/softcore-velocity-s01/
description: ''
image: /assets/covers/softcore-velocity-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:22'
album: The Way the Air Moves
mood:
- Aggressive
genre:
- lo-fi
- jungle
- soul
bpm: 150
key: Ab
image_jpg: /assets/covers/softcore-velocity-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
