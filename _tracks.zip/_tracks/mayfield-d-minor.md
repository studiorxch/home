---
layout: track
title: Mayfield (D-Minor)
permalink: /tracks/mayfield-d-minor/
description: ''
image: /assets/covers/mayfield-d-minor.webp
image_ready: false
date: 2025-01-01
duration: '4:00'
album: Stranger Vibes
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
bpm: 88
key: D
image_jpg: /assets/covers/mayfield-d-minor.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
