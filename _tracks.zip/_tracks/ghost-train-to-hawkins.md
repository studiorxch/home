---
layout: track
title: "Ghost Train To Hawkins"
permalink: /tracks/ghost-train-to-hawkins/
description: ""
image: "/assets/covers/ghost-train-to-hawkins.webp"
image_ready: false
date: 2025-01-01
duration: "2:01"
album: "Stranger Vibes"
mood: ["Aggressive"]
genre: ["lo-fi hip hop", "downtempo", "chillhop"]
bpm: 143
key: "F"
---

Explore more vibes in the [StudioRich track library](/tracks/).
