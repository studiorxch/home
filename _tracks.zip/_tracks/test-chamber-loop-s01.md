---
layout: track
title: "Test Chamber Loop S01"
permalink: /tracks/test-chamber-loop-s01/
description: ""
image: "/assets/covers/test-chamber-loop-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:21"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi", "chillhop", "ambient"]
bpm: 80
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
