---
layout: track
title: Ember Channel
permalink: /tracks/ember-channel/
description: ''
image: /assets/covers/ember-channel.webp
image_ready: false
date: 2025-01-01
duration: '2:07'
album: The Way the Air Moves
mood:
- Playful
genre:
- ambient
- lo-fi
- jungle
bpm: 90
key: F#
image_jpg: /assets/covers/ember-channel.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
