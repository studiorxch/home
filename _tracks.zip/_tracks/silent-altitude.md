---
layout: track
title: "Silent Altitude"
permalink: /tracks/silent-altitude/
description: ""
image: "/assets/covers/silent-altitude.webp"
image_ready: false
date: 2025-01-01
duration: "2:14"
album: "The Way the Air Moves"
mood: ["Melancholy"]
genre: ["lo-fi", "jungle", "electronica"]
bpm: 80
key: "E"
---

Explore more vibes in the [StudioRich track library](/tracks/).
