---
layout: track
title: Faint Return S01
permalink: /tracks/faint-return-s01/
description: ''
image: /assets/covers/faint-return-s01.webp
image_ready: false
date: 2025-01-01
duration: '3:46'
album: The Way the Air Moves
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- electronic
bpm: 87
key: B
image_jpg: /assets/covers/faint-return-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
