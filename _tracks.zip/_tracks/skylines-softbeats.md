---
layout: track
title: Skylines & Softbeats
permalink: /tracks/skylines-softbeats/
description: ''
image: /assets/covers/skylines-softbeats.webp
image_ready: false
date: 2025-01-01
duration: '7:12'
album: The Way the Air Moves
mood:
- Playful
genre:
- ambient
- lo-fi
- jungle
bpm: 95
key: A
image_jpg: /assets/covers/skylines-softbeats.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
