---
layout: track
title: Mirror Shard S01
permalink: /tracks/mirror-shard-s01/
description: ''
image: /assets/covers/mirror-shard-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:11'
album: Stranger Vibes
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- experimental
- ambient
bpm: 86
key: C
image_jpg: /assets/covers/mirror-shard-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
