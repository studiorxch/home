---
layout: track
title: Hold The Shape S1
permalink: /tracks/hold-the-shape-s1/
description: ''
image: /assets/covers/hold-the-shape-s1.webp
image_ready: false
date: 2025-01-01
duration: '1:13'
album: Run Loop
mood:
- Aggressive
genre:
- jungle
- ambient
bpm: 150
key: E
image_jpg: /assets/covers/hold-the-shape-s1.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
