---
layout: track
title: Fourth Period Fog
permalink: /tracks/fourth-period-fog/
description: ''
image: /assets/covers/fourth-period-fog.webp
image_ready: false
date: 2025-01-01
duration: '1:41'
album: Stranger Vibes
mood:
- Playful
genre:
- lo-fi
- indie
- dream pop
bpm: 94
key: C#
image_jpg: /assets/covers/fourth-period-fog.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
