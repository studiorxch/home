---
layout: track
title: Window Crash Sequence
permalink: /tracks/window-crash-sequence/
description: ''
image: /assets/covers/window-crash-sequence.webp
image_ready: false
date: 2025-01-01
duration: '2:27'
album: Run Loop
mood:
- Melancholy
genre:
- drum and bass
- ambient
bpm: 71
key: F#
image_jpg: /assets/covers/window-crash-sequence.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
