---
layout: track
title: "Quiet Geometry"
permalink: /tracks/quiet-geometry/
description: ""
image: "/assets/covers/quiet-geometry.webp"
image_ready: false
date: 2025-01-01
duration: "2:14"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "instrumental"]
bpm: 86
key: "D"
---

Explore more vibes in the [StudioRich track library](/tracks/).
