---
layout: track
title: "Sweatshirt Blur S1"
permalink: /tracks/sweatshirt-blur-s1/
description: ""
image: "/assets/covers/sweatshirt-blur-s1.webp"
image_ready: false
date: 2025-01-01
duration: "1:45"
album: "Run Loop"
mood: ["Dreamy"]
genre: ["r&b", "trap"]
bpm: 96
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
