---
layout: track
title: "Drift Tempo"
permalink: /tracks/drift-tempo/
description: ""
image: "/assets/covers/drift-tempo.webp"
image_ready: false
date: 2025-01-01
duration: "2:09"
album: "The Way the Air Moves"
mood: ["Aggressive"]
genre: ["lo-fi", "jungle", "piano"]
bpm: 150
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
