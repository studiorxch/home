---
layout: track
title: "A New Dawn"
permalink: /tracks/a-new-dawn/
description: ""
image: "/assets/covers/a-new-dawn.webp"
image_ready: true
date: 2025-01-01
duration: "3:09"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi"]
bpm: 84
key: "A"
---

Explore more vibes in the [StudioRich track library](/tracks/).
