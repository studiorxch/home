---
layout: track
title: Tape From The Other Side (Studiorich Edit)
permalink: /tracks/tape-from-the-other-side-studiorich-edit/
description: ''
image: /assets/covers/tape-from-the-other-side-studiorich-edit.webp
image_ready: false
date: 2025-01-01
duration: '1:27'
album: Stranger Vibes
mood:
- Aggressive
genre:
- lo-fi
- synthwave
- 80s nostalgia
bpm: 152
key: Eb
image_jpg: /assets/covers/tape-from-the-other-side-studiorich-edit.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
