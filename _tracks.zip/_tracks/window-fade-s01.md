---
layout: track
title: Window Fade S01
permalink: /tracks/window-fade-s01/
description: ''
image: /assets/covers/window-fade-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:04'
album: Stranger Vibes
mood:
- Chill
genre:
- lo-fi
- cinematic
- chill
bpm: 85
key: C
image_jpg: /assets/covers/window-fade-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
