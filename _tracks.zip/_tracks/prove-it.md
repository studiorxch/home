---
layout: track
title: "Prove It"
permalink: /tracks/prove-it/
description: ""
image: "/assets/covers/prove-it.webp"
image_ready: false
date: 2025-01-01
duration: "2:33"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi", "jazz", "soul"]
bpm: 88
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
