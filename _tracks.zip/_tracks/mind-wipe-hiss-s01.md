---
layout: track
title: "Mind Wipe Hiss S01"
permalink: /tracks/mind-wipe-hiss-s01/
description: ""
image: "/assets/covers/mind-wipe-hiss-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:02"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "cinematic", "electronic"]
bpm: 130
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
