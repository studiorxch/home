---
layout: track
title: "Static Door Echo S01"
permalink: /tracks/static-door-echo-s01/
description: ""
image: "/assets/covers/static-door-echo-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:03"
album: "Stranger Vibes"
mood: ["Hopeful"]
genre: ["lo-fi", "ambient", "electronic"]
bpm: 113
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
