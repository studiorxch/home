---
layout: track
title: "Solitude's Reflection"
permalink: /tracks/solitudes-reflection/
description: ""
image: "/assets/covers/solitudes-reflection.webp"
image_ready: false
date: 2025-01-01
duration: "1:46"
album: "Stranger Vibes"
mood: ["Chill", "Weightless"]
genre: ["lo-fi"]
bpm: 64
key: "A"
---

Explore more vibes in the [StudioRich track library](/tracks/).
