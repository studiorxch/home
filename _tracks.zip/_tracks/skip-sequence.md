---
layout: track
title: "Skip Sequence"
permalink: /tracks/skip-sequence/
description: ""
image: "/assets/covers/skip-sequence.webp"
image_ready: false
date: 2025-01-01
duration: "2:17"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["ambient", "lo-fi", "jungle"]
bpm: 85
key: "B"
---

Explore more vibes in the [StudioRich track library](/tracks/).
