---
layout: track
title: Glass Transit S01
permalink: /tracks/glass-transit-s01/
description: ''
image: /assets/covers/glass-transit-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:50'
album: The Way the Air Moves
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- experimental
bpm: 90
key: B
image_jpg: /assets/covers/glass-transit-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
