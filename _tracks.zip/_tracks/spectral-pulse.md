---
layout: track
title: "Spectral Pulse"
permalink: /tracks/spectral-pulse/
description: ""
image: "/assets/covers/spectral-pulse.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Eunoia"
mood: ["Hopeful"]
genre: ["ambient", "electronic", "experimental"]
bpm: 120
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
