---
layout: track
title: Mouth Breather Blues
permalink: /tracks/mouth-breather-blues/
description: ''
image: /assets/covers/mouth-breather-blues.webp
image_ready: false
date: 2025-01-01
duration: '3:12'
album: Stranger Vibes
mood:
- Melancholy
- Weightless
genre:
- lo-fi
- ambient
- experimental electronic
bpm: 68
key: F
image_jpg: /assets/covers/mouth-breather-blues.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
