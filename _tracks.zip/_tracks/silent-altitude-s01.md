---
layout: track
title: Silent Altitude S01
permalink: /tracks/silent-altitude-s01/
description: ''
image: /assets/covers/silent-altitude-s01.webp
image_ready: false
date: 2025-01-01
duration: '1:18'
album: The Way the Air Moves
mood:
- Aggressive
genre:
- lo-fi
- jungle
- electronica
bpm: 150
key: E
image_jpg: /assets/covers/silent-altitude-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
