---
layout: track
title: "Blurred Signal"
permalink: /tracks/blurred-signal/
description: ""
image: "/assets/covers/blurred-signal.webp"
image_ready: false
date: 2025-01-01
duration: "2:14"
album: "The Way the Air Moves"
mood: ["Melancholy"]
genre: ["lo-fi", "jungle", "nostalgic"]
bpm: 80
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
