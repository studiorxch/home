---
layout: track
title: "Lucas Loop S01"
permalink: /tracks/lucas-loop-s01/
description: ""
image: "/assets/covers/lucas-loop-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:14"
album: "Stranger Vibes"
mood: ["Melancholy"]
genre: ["lo-fi", "chillhop", "ambient"]
bpm: 76
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
