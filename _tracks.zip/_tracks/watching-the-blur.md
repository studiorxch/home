---
layout: track
title: "Watching the Blur"
permalink: /tracks/watching-the-blur/
description: ""
image: "/assets/covers/watching-the-blur.webp"
image_ready: false
date: 2025-01-01
duration: "4:14"
album: "Run Loop"
mood: ["Melancholy", "Dreamy", "Nostalgic"]
genre: ["ambient", "jungle"]
bpm: 85
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
