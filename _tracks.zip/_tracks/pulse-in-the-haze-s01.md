---
layout: track
title: "Pulse in the Haze S01"
permalink: /tracks/pulse-in-the-haze-s01/
description: ""
image: "/assets/covers/pulse-in-the-haze-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:39"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 84
key: "E"
---

Explore more vibes in the [StudioRich track library](/tracks/).
