---
layout: track
title: "Gravity Chord"
permalink: /tracks/gravity-chord/
description: ""
image: "/assets/covers/gravity-chord.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Eunoia"
mood: ["Tense"]
genre: ["ambient", "electronic", "experimental"]
bpm: 125
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
