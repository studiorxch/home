---
layout: track
title: Hoppers Cabin Glow S01
permalink: /tracks/hoppers-cabin-glow-s01/
description: ''
image: /assets/covers/hoppers-cabin-glow-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:13'
album: Stranger Vibes
mood:
- Tense
genre:
- lo-fi
- cinematic
- melancholy
bpm: 120
key: G
image_jpg: /assets/covers/hoppers-cabin-glow-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
