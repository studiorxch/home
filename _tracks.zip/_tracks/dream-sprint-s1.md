---
layout: track
title: "Dream Sprint S1"
permalink: /tracks/dream-sprint-s1/
description: ""
image: "/assets/covers/dream-sprint-s1.webp"
image_ready: false
date: 2025-01-01
duration: "3:43"
album: "Run Loop"
mood: ["Dreamy", "Nostalgic"]
genre: ["electronic", "jungle", "synthpop"]
bpm: 87
key: "E"
---

Explore more vibes in the [StudioRich track library](/tracks/).
