---
layout: track
title: "Empty Hall Echo"
permalink: /tracks/empty-hall-echo/
description: ""
image: "/assets/covers/empty-hall-echo.webp"
image_ready: false
date: 2025-01-01
duration: "1:33"
album: "Stranger Vibes"
mood: ["Hopeful"]
genre: ["lo-fi", "ambient", "experimental"]
bpm: 112
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
