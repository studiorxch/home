---
layout: track
title: "Fast Crush S01"
permalink: /tracks/fast-crush-s01/
description: ""
image: "/assets/covers/fast-crush-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:24"
album: "The Way the Air Moves"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 162
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
