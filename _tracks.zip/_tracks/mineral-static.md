---
layout: track
title: Mineral Static
permalink: /tracks/mineral-static/
description: ''
image: /assets/covers/mineral-static.webp
image_ready: false
date: 2025-01-01
duration: '3:05'
album: Eunoia
mood:
- Dreamy
genre:
- ambient
- electronic
- experimental
bpm: 103
key: D
image_jpg: /assets/covers/mineral-static.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
