---
layout: track
title: Same Apartment Different Light
permalink: /tracks/same-apartment-different-light/
description: ''
image: /assets/covers/same-apartment-different-light.webp
image_ready: false
date: 2025-01-01
duration: '3:07'
album: Run Loop
mood:
- Playful
genre:
- ambient
- electronic
bpm: 100
key: G
image_jpg: /assets/covers/same-apartment-different-light.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
