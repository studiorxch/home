---
layout: track
title: Cassette Gravity S01
permalink: /tracks/cassette-gravity-s01/
description: ''
image: /assets/covers/cassette-gravity-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:27'
album: Stranger Vibes
mood:
- Melancholy
genre:
- lo-fi
- experimental
- ambient
bpm: 78
key: Ab
image_jpg: /assets/covers/cassette-gravity-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
