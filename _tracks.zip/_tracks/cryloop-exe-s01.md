---
layout: track
title: Cryloop.exe S01
permalink: /tracks/cryloop-exe-s01/
description: ''
image: /assets/covers/cryloop-exe-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:43'
album: The Way the Air Moves
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- experimental
bpm: 83
key: G
image_jpg: /assets/covers/cryloop-exe-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
