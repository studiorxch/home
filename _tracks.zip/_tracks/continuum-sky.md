---
layout: track
title: "Continuum Sky"
permalink: /tracks/continuum-sky/
description: ""
image: "/assets/covers/continuum-sky.webp"
image_ready: false
date: 2025-01-01
duration: "4:00"
album: "Eunoia"
mood: ["Dreamy", "Nostalgic"]
genre: ["ambient", "electronic", "experimental"]
bpm: 88
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
