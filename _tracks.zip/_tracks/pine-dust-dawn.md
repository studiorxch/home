---
layout: track
title: Pine Dust Dawn
permalink: /tracks/pine-dust-dawn/
description: ''
image: /assets/covers/pine-dust-dawn.webp
image_ready: false
date: 2025-01-01
duration: '3:11'
album: Stranger Vibes
mood:
- Hopeful
- Playful
genre:
- lo-fi
- cinematic
- glitch
bpm: 100
key: F
image_jpg: /assets/covers/pine-dust-dawn.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
