---
layout: track
title: Petal Fade S01
permalink: /tracks/petal-fade-s01/
description: ''
image: /assets/covers/petal-fade-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:35'
album: The Way the Air Moves
mood:
- Energetic
- Aggressive
genre:
- cinematic
- lo-fi
- jungle
bpm: 172
key: E
image_jpg: /assets/covers/petal-fade-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
