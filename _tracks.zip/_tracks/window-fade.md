---
layout: track
title: Window Fade
permalink: /tracks/window-fade/
description: ''
image: /assets/covers/window-fade.webp
image_ready: false
date: 2025-01-01
duration: '1:41'
album: Stranger Vibes
mood:
- Chill
genre:
- lo-fi
- cinematic
- chill
bpm: 85
key: Bb
image_jpg: /assets/covers/window-fade.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
