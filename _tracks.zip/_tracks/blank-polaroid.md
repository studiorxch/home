---
layout: track
title: "Blank Polaroid"
permalink: /tracks/blank-polaroid/
description: ""
image: "/assets/covers/blank-polaroid.webp"
image_ready: false
date: 2025-01-01
duration: "0:59"
album: "Run Loop"
mood: ["Aggressive"]
genre: ["ambient", "instrumental"]
bpm: 144
key: "B"
---

Explore more vibes in the [StudioRich track library](/tracks/).
