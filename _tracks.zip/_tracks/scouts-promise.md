---
layout: track
title: Scout's Promise
permalink: /tracks/scouts-promise/
description: ''
image: /assets/covers/scouts-promise.webp
image_ready: false
date: 2025-01-01
duration: '2:32'
album: Stranger Vibes
mood:
- Chill
genre:
- lo-fi
- chillhop
- electronic
bpm: 88
key: B
image_jpg: /assets/covers/scouts-promise.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
