---
layout: track
title: "Love Error 1997 S1"
permalink: /tracks/love-error-1997-s1/
description: ""
image: "/assets/covers/love-error-1997-s1.webp"
image_ready: false
date: 2025-01-01
duration: "4:13"
album: "Run Loop"
mood: ["Melancholy", "Weightless"]
genre: ["jungle", "experimental electronic"]
bpm: 68
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
