---
layout: track
title: "Cloud Rust"
permalink: /tracks/cloud-rust/
description: ""
image: "/assets/covers/cloud-rust.webp"
image_ready: false
date: 2025-01-01
duration: "1:47"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "ambient"]
bpm: 90
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
