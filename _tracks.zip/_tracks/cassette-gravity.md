---
layout: track
title: "Cassette Gravity"
permalink: /tracks/cassette-gravity/
description: ""
image: "/assets/covers/cassette-gravity.webp"
image_ready: false
date: 2025-01-01
duration: "2:26"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "experimental", "ambient"]
bpm: 118
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
