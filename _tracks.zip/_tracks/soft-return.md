---
layout: track
title: "Soft Return"
permalink: /tracks/soft-return/
description: ""
image: "/assets/covers/soft-return.webp"
image_ready: false
date: 2025-01-01
duration: "2:30"
album: "Stranger Vibes"
mood: ["Chill"]
genre: ["lo-fi", "ambient"]
bpm: 89
key: "Eb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
