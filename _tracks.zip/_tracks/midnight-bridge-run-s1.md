---
layout: track
title: Midnight Bridge Run S1
permalink: /tracks/midnight-bridge-run-s1/
description: ''
image: /assets/covers/midnight-bridge-run-s1.webp
image_ready: false
date: 2025-01-01
duration: '6:57'
album: Run Loop
mood: []
genre:
- jungle
- drum and bass
- atmospheric
bpm: 120
key: C
image_jpg: /assets/covers/midnight-bridge-run-s1.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
