---
layout: track
title: "Red Sky Break"
permalink: /tracks/red-sky-break/
description: ""
image: "/assets/covers/red-sky-break.webp"
image_ready: false
date: 2025-01-01
duration: "2:05"
album: "Stranger Vibes"
mood: ["Melancholy"]
genre: ["lo-fi", "experimental", "ambient"]
bpm: 78
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
