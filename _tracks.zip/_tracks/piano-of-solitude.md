---
layout: track
title: Piano Of Solitude
permalink: /tracks/piano-of-solitude/
description: ''
image: /assets/covers/piano-of-solitude.webp
image_ready: false
date: 2025-01-01
duration: '2:32'
album: Stranger Vibes
mood:
- Tense
genre:
- lo-fi
bpm: 120
key: A
image_jpg: /assets/covers/piano-of-solitude.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
