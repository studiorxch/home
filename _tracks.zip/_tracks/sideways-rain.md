---
layout: track
title: "Sideways Rain"
permalink: /tracks/sideways-rain/
description: ""
image: "/assets/covers/sideways-rain.webp"
image_ready: false
date: 2025-01-01
duration: "3:11"
album: "Run Loop"
mood: ["Tense"]
genre: ["electronic", "breakbeat", "ambient"]
bpm: 130
key: "E"
---

Explore more vibes in the [StudioRich track library](/tracks/).
