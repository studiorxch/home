---
layout: track
title: Voice Inside Static
permalink: /tracks/voice-inside-static/
description: ''
image: /assets/covers/voice-inside-static.webp
image_ready: false
date: 2025-01-01
duration: '5:03'
album: Run Loop
mood:
- Hopeful
genre:
- ambient
- jungle
- dream pop
bpm: 120
key: C
image_jpg: /assets/covers/voice-inside-static.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
