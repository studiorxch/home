---
layout: track
title: Tape From The Other Side
permalink: /tracks/tape-from-the-other-side/
description: ''
image: /assets/covers/tape-from-the-other-side.webp
image_ready: false
date: 2025-01-01
duration: '1:26'
album: Stranger Vibes
mood:
- Melancholy
genre:
- lo-fi
- synthwave
- 80s nostalgia
bpm: 76
key: Eb
image_jpg: /assets/covers/tape-from-the-other-side.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
