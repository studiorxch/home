---
layout: track
title: Ghost Loop S1
permalink: /tracks/ghost-loop-s1/
description: ''
image: /assets/covers/ghost-loop-s1.webp
image_ready: false
date: 2025-01-01
duration: '5:39'
album: Run Loop
mood:
- Tense
genre:
- ambient
- experimental
bpm: 120
key: B
image_jpg: /assets/covers/ghost-loop-s1.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
