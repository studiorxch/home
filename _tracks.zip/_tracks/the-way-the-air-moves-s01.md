---
layout: track
title: The Way the Air Moves S01
permalink: /tracks/the-way-the-air-moves-s01/
description: ''
image: /assets/covers/the-way-the-air-moves-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:51'
album: The Way the Air Moves
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- ambient
bpm: 85
key: Eb
image_jpg: /assets/covers/the-way-the-air-moves-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
