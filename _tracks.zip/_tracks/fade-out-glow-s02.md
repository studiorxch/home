---
layout: track
title: Fade Out Glow S02
permalink: /tracks/fade-out-glow-s02/
description: ''
image: /assets/covers/fade-out-glow-s02.webp
image_ready: false
date: 2025-01-01
duration: '1:59'
album: Stranger Vibes
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- downtempo
- chillhop
bpm: 80
key: B
image_jpg: /assets/covers/fade-out-glow-s02.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
