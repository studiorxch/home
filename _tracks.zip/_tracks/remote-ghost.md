---
layout: track
title: "Remote Ghost"
permalink: /tracks/remote-ghost/
description: "Remote Ghost is a Dark, Dreamy, Lonely, Melancholy track blending lo-fi, dream pop, ambient with deep focus energy."
image: "/assets/covers/remote-ghost.webp"
image_ready: false
date: 2025-01-01
duration: "2:15"
album: "Stranger Vibes"
mood: ["Aggressive"]
genre: ["lo-fi", "dream pop", "ambient"]
bpm: 140
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
