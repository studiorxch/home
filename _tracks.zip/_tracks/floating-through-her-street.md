---
layout: track
title: "Floating Through Her Street"
permalink: /tracks/floating-through-her-street/
description: ""
image: "/assets/covers/floating-through-her-street.webp"
image_ready: false
date: 2025-01-01
duration: "1:56"
album: "Run Loop"
mood: ["Energetic", "Aggressive"]
genre: ["ambient", "downtempo"]
bpm: 166
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
