---
layout: track
title: Brotherhood Beat S01
permalink: /tracks/brotherhood-beat-s01/
description: ''
image: /assets/covers/brotherhood-beat-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:03'
album: Stranger Vibes
mood:
- Dreamy
- Nostalgic
genre:
- lo-fi
- indie
- chill
bpm: 93
key: Bb
image_jpg: /assets/covers/brotherhood-beat-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
