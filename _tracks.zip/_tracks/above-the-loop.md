---
layout: track
title: Above the Loop
permalink: /tracks/above-the-loop/
description: ''
image: /assets/covers/above-the-loop.webp
image_ready: false
date: 2025-01-01
duration: '1:42'
album: The Way the Air Moves
mood:
- Chill
genre:
- cinematic
- lo-fi
- jungle
bpm: 90
key: F
image_jpg: /assets/covers/above-the-loop.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
