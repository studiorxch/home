---
layout: track
title: "Glass Drift S01"
permalink: /tracks/glass-drift-s01/
description: ""
image: "/assets/covers/glass-drift-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:33"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["lo-fi", "jungle", "electronic"]
bpm: 85
key: "D"
---

Explore more vibes in the [StudioRich track library](/tracks/).
