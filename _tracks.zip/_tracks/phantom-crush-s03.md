---
layout: track
title: "Phantom Crush S03"
permalink: /tracks/phantom-crush-s03/
description: ""
image: "/assets/covers/phantom-crush-s03.webp"
image_ready: false
date: 2025-01-01
duration: "1:35"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["cinematic", "lo-fi", "jungle"]
bpm: 80
key: "C#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
