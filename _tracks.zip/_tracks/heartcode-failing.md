---
layout: track
title: "Heartcode Failing"
permalink: /tracks/heartcode-failing/
description: ""
image: "/assets/covers/heartcode-failing.webp"
image_ready: false
date: 2025-01-01
duration: "2:27"
album: "Run Loop"
mood: []
genre: ["electronic", "experimental pop"]
bpm: 110
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
