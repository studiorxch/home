---
layout: track
title: "Watching the Blur S1"
permalink: /tracks/watching-the-blur-s1/
description: ""
image: "/assets/covers/watching-the-blur-s1.webp"
image_ready: false
date: 2025-01-01
duration: "2:30"
album: "Run Loop"
mood: ["Dreamy", "Nostalgic"]
genre: ["ambient", "jungle"]
bpm: 86
key: "F"
---

Explore more vibes in the [StudioRich track library](/tracks/).
