---
layout: track
title: "Phantom Crush S02"
permalink: /tracks/phantom-crush-s02/
description: ""
image: "/assets/covers/phantom-crush-s02.webp"
image_ready: false
date: 2025-01-01
duration: "2:40"
album: "The Way the Air Moves"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi", "jungle", "electronic"]
bpm: 172
key: "D"
---

Explore more vibes in the [StudioRich track library](/tracks/).
