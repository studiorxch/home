---
layout: track
title: "Radiant Brake S01"
permalink: /tracks/radiant-brake-s01/
description: ""
image: "/assets/covers/radiant-brake-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:19"
album: "The Way the Air Moves"
mood: ["Melancholy"]
genre: ["cinematic", "lo-fi", "jungle"]
bpm: 77
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
