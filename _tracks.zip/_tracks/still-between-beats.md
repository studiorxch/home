---
layout: track
title: "Still Between Beats"
permalink: /tracks/still-between-beats/
description: ""
image: "/assets/covers/still-between-beats.webp"
image_ready: false
date: 2025-01-01
duration: "2:36"
album: "The Way the Air Moves"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi", "jungle", "electronic"]
bpm: 162
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
