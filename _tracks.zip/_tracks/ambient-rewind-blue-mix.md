---
layout: track
title: "Ambient Rewind Blue Mix"
permalink: /tracks/ambient-rewind-blue-mix/
description: ""
image: "/assets/covers/ambient-rewind-blue-mix.webp"
image_ready: false
date: 2025-01-01
duration: "1:39"
album: "Run Loop"
mood: ["Chill"]
genre: ["lo-fi", "instrumental", "ambient"]
bpm: 87
key: "Bb"
---

Explore more vibes in the [StudioRich track library](/tracks/).
