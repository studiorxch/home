---
layout: track
title: "Soft Entry"
permalink: /tracks/soft-entry/
description: ""
image: "/assets/covers/soft-entry.webp"
image_ready: false
date: 2025-01-01
duration: "1:38"
album: "Stranger Vibes"
mood: ["Hopeful", "Playful"]
genre: ["lo-fi"]
bpm: 101
key: "A"
---

Explore more vibes in the [StudioRich track library](/tracks/).
