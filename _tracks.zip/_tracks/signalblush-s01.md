---
layout: track
title: Signalblush S01
permalink: /tracks/signalblush-s01/
description: ''
image: /assets/covers/signalblush-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:39'
album: The Way the Air Moves
mood:
- Aggressive
genre:
- ambient
- lo-fi
- dub
bpm: 145
key: G
image_jpg: /assets/covers/signalblush-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
