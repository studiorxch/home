---
layout: track
title: Hoppers Cabin Glow
permalink: /tracks/hoppers-cabin-glow/
description: ''
image: /assets/covers/hoppers-cabin-glow.webp
image_ready: false
date: 2025-01-01
duration: '2:36'
album: Stranger Vibes
mood:
- Hopeful
- Playful
genre:
- lo-fi
- cinematic
- melancholy
bpm: 107
key: F
image_jpg: /assets/covers/hoppers-cabin-glow.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
