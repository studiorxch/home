---
layout: track
title: Altocumulus S01
permalink: /tracks/altocumulus-s01/
description: ""
image: /assets/covers/altocumulus-s01.webp
image_ready: false
date: 2025-01-01
duration: 2:15
album: The Way the Air Moves
mood:
  - Melancholy
genre:
  - lo-fi
  - jungle
  - dream pop
bpm: 78
key: Bb
---

Explore more vibes in the [StudioRich track library](/tracks/).
