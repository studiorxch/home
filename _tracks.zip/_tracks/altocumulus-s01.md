---
layout: track
title: Altocumulus S01
permalink: /tracks/altocumulus-s01/
description: ''
image: /assets/covers/altocumulus-s01.webp
image_ready: false
date: 2025-01-01
duration: 135
album: The Way the Air Moves
mood:
- Melancholy
genre:
- lo-fi
- jungle
- dream pop
bpm: 78
key: Bb
image_jpg: /assets/covers/altocumulus-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
