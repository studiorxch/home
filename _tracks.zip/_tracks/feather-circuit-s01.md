---
layout: track
title: Feather Circuit S01
permalink: /tracks/feather-circuit-s01/
description: ''
image: /assets/covers/feather-circuit-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:19'
album: The Way the Air Moves
mood:
- Chill
genre:
- cinematic
- lo-fi
- jungle
bpm: 80
key: C#
image_jpg: /assets/covers/feather-circuit-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
