---
layout: track
title: "Dustins Compass S01"
permalink: /tracks/dustins-compass-s01/
description: ""
image: "/assets/covers/dustins-compass-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:05"
album: "Stranger Vibes"
mood: ["Tense"]
genre: ["lo-fi", "chillhop", "ambient"]
bpm: 121
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
