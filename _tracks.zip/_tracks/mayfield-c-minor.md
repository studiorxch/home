---
layout: track
title: "Mayfield (C-Minor)"
permalink: /tracks/mayfield-c-minor/
description: ""
image: "/assets/covers/mayfield-c-minor.webp"
image_ready: false
date: 2025-01-01
duration: "2:07"
album: "Stranger Vibes"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi"]
bpm: 178
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
