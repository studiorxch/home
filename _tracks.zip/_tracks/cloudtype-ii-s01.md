---
layout: track
title: "Cloudtype II S01"
permalink: /tracks/cloudtype-ii-s01/
description: ""
image: "/assets/covers/cloudtype-ii-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:02"
album: "The Way the Air Moves"
mood: ["Chill"]
genre: ["ambient", "lo-fi", "chillout"]
bpm: 80
key: "F#"
---

Explore more vibes in the [StudioRich track library](/tracks/).
