---
layout: track
title: "Sidewalk Sunrise"
permalink: /tracks/sidewalk-sunrise/
description: ""
image: "/assets/covers/sidewalk-sunrise.webp"
image_ready: false
date: 2025-01-01
duration: "2:20"
album: "Stranger Vibes"
mood: ["Energetic", "Aggressive"]
genre: ["lo-fi"]
bpm: 166
key: "C"
---

Explore more vibes in the [StudioRich track library](/tracks/).
