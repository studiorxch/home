---
layout: track
title: Weight of Nothing
permalink: /tracks/weight-of-nothing/
description: ''
image: /assets/covers/weight-of-nothing.webp
image_ready: false
date: 2025-01-01
duration: '2:31'
album: The Way the Air Moves
mood:
- Melancholy
- Dreamy
- Nostalgic
genre:
- lo-fi
- jungle
- electronic
bpm: 82
key: A
image_jpg: /assets/covers/weight-of-nothing.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
