---
layout: track
title: Orbital Lull
permalink: /tracks/orbital-lull/
description: ''
image: /assets/covers/orbital-lull.webp
image_ready: false
date: 2025-01-01
duration: '2:40'
album: Eunoia
mood:
- Tense
genre:
- ambient
- electronic
- experimental
bpm: 120
key: E
image_jpg: /assets/covers/orbital-lull.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
