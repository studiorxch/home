---
layout: track
title: "Red Sky Break S01"
permalink: /tracks/red-sky-break-s01/
description: ""
image: "/assets/covers/red-sky-break-s01.webp"
image_ready: false
date: 2025-01-01
duration: "2:07"
album: "Stranger Vibes"
mood: ["Aggressive"]
genre: ["lo-fi", "experimental", "ambient"]
bpm: 154
key: "Ab"
---

Explore more vibes in the [StudioRich track library](/tracks/).
