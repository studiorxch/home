---
layout: track
title: Neon With Teeth
permalink: /tracks/neon-with-teeth/
description: ''
image: /assets/covers/neon-with-teeth.webp
image_ready: false
date: 2025-01-01
duration: '2:11'
album: The Way the Air Moves
mood:
- Energetic
- Aggressive
genre:
- lo-fi
- jungle
- ambient
bpm: 172
key: A
image_jpg: /assets/covers/neon-with-teeth.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
