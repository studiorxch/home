---
layout: track
title: Halo Fade
permalink: /tracks/halo-fade/
description: ''
image: /assets/covers/halo-fade.webp
image_ready: false
date: 2025-01-01
duration: '2:57'
album: The Way the Air Moves
mood:
- Chill
genre:
- lo-fi
- jungle
- soul
bpm: 77
key: Eb
image_jpg: /assets/covers/halo-fade.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
