---
layout: track
title: Near Her Window S1
permalink: /tracks/near-her-window-s1/
description: ''
image: /assets/covers/near-her-window-s1.webp
image_ready: false
date: 2025-01-01
duration: '3:07'
album: Run Loop
mood:
- Dreamy
- Nostalgic
genre:
- ambient
- electronic
bpm: 94
key: A
image_jpg: /assets/covers/near-her-window-s1.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
