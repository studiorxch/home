---
layout: track
title: "Ghostbusters Groove S01"
permalink: /tracks/ghostbusters-groove-s01/
description: "Ghostbusters Groove S01 is a lo-fi, experimental track — 92 BPM in D. Mood: playful, nostalgic. VHS fuzz and spectral basslines echo through boom-bap tape hiss."
image: "/assets/covers/ghostbusters-groove-s01.webp"
image_ready: false
date: 2025-01-01
duration: "3:05"
album: "Stranger Vibes"
mood: []
genre: ["lo-fi", "cinematic", "ambient"]
bpm: 114
key: "D"
---

Explore more vibes in the [StudioRich track library](/tracks/).
