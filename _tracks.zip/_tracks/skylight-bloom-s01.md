---
layout: track
title: Skylight Bloom S01
permalink: /tracks/skylight-bloom-s01/
description: ''
image: /assets/covers/skylight-bloom-s01.webp
image_ready: false
date: 2025-01-01
duration: '2:18'
album: The Way the Air Moves
mood:
- Chill
genre:
- lo-fi
- jungle
- electronic
bpm: 80
key: F#
image_jpg: /assets/covers/skylight-bloom-s01.jpg
---

Explore more vibes in the [StudioRich track library](/tracks/).
