---
layout: track
title: "Blank Polaroid S1"
permalink: /tracks/blank-polaroid-s1/
description: ""
image: "/assets/covers/blank-polaroid-s1.webp"
image_ready: false
date: 2025-01-01
duration: "5:03"
album: "Run Loop"
mood: ["Hopeful"]
genre: ["ambient", "instrumental"]
bpm: 118
key: "G"
---

Explore more vibes in the [StudioRich track library](/tracks/).
