---
layout: redirect
redirect_from: /products/lo-fi-stealth-mode-tee-red-kitty-edition
redirect_to: /shop
---
