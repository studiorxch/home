---
layout: redirect
redirect_from: /blogs/studiorich-chronicles-snapshots-threads-from-the-nyc-streets/unearthing-the-ancestral-whiskers-felix-through-the-looking-glass
redirect_to: /blog/
---
