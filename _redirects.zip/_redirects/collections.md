---
layout: redirect
redirect_from: /collections
redirect_to: /shop
---
