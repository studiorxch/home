---
layout: redirect
redirect_from: /pages/contact
redirect_to: /about
---
