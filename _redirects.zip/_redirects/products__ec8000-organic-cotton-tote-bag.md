---
layout: redirect
redirect_from: /products/ec8000-organic-cotton-tote-bag
redirect_to: /shop
---
