---
layout: redirect
redirect_from: /collections/t-shirts.atom
redirect_to: /shop
---
