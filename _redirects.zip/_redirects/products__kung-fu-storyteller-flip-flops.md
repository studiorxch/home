---
layout: redirect
redirect_from: /products/kung-fu-storyteller-flip-flops
redirect_to: /shop
---
