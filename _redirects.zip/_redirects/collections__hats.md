---
layout: redirect
redirect_from: /collections/hats
redirect_to: /shop
---
