---
layout: redirect
redirect_from: /collections/all
redirect_to: /shop
---
