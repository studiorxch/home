---
layout: redirect
redirect_from: /cdn/shop/t/14/assets/variant-picker.js
redirect_to: /shop
---
