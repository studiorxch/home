---
layout: redirect
redirect_from: 
- /blogs/lo-fi-sundays
- /lo-fi-sundays-sweet-dreams
- /lo-fi-sundays
- /pages/lo-fi-sundays
- /pages/schedule
- /schedule
- /schedule/${slug}
redirect_to: /schedule/sunday
---
