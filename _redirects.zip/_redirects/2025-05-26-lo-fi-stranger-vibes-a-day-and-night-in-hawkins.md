---
layout: redirect
redirect_from: /2025/05/26/lo-fi-stranger-vibes-a-day-and-night-in-hawkins.html
redirect_to: /field-notes/2025/05/26/lo-fi-stranger-vibes-a-day-and-night-in-hawkins.html
---
