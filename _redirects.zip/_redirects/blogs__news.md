---
layout: redirect
redirect_from: /blogs/news
redirect_to: /blog
---
