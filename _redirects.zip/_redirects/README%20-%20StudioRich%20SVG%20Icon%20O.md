---
layout: redirect
redirect_from: /assets/icons/README%20-%20StudioRich%20SVG%20Icon%20Optimization.html
redirect_to: /coming-soon
---
