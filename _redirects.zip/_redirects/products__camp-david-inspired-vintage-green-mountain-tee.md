---
layout: redirect
redirect_from: /products/camp-david-inspired-vintage-green-mountain-tee
redirect_to: /shop
---
